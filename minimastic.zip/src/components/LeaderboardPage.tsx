import React from "react";
import { motion } from "motion/react";
import { 
  Trophy, 
  Sparkles, 
  ChevronRight, 
  Flame, 
  UserPlus, 
  Swords, 
  ShieldAlert, 
  Globe, 
  Activity, 
  Zap, 
  Target
} from "lucide-react";
import { LeaderboardItem } from "../types";

interface LeaderboardPageProps {
  leaderboard: LeaderboardItem[];
  currentUserName: string;
}

export const LeaderboardPage: React.FC<LeaderboardPageProps> = ({ leaderboard, currentUserName }) => {
  // Extract top 3 for styled podium
  const topThree = leaderboard.slice(0, 3);
  const others = leaderboard.slice(3);

  const getMedalColor = (rank: number) => {
    switch (rank) {
      case 1: return "bg-amber-400 text-slate-900 border-amber-300 ring-amber-100";
      case 2: return "bg-slate-350 text-slate-900 border-slate-300 ring-slate-150";
      case 3: return "bg-amber-600 text-white border-amber-500 ring-amber-200";
      default: return "bg-slate-100 text-slate-500 border-slate-200 ring-slate-50";
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-8" id="minimastic-leaderboard">
      
      {/* Upper gamification banner */}
      <div className="flex flex-col sm:flex-row items-center justify-between p-6 bg-gradient-to-r from-indigo-900 to-indigo-950 text-white rounded-[24px] border border-indigo-800 shadow-md gap-4 text-left">
        <div className="space-y-1">
          <div className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-200 text-[10px] font-bold uppercase tracking-wider">
            <Globe className="w-3.5 h-3.5 text-indigo-400" />
            <span>Global Arena live</span>
          </div>
          <h3 className="text-xl font-bold tracking-tight">Daily Quiz Champions</h3>
          <p className="text-indigo-200 text-xs font-light max-w-sm">
            Work with Gemini customized assessments continuously to level up, preserve daily streaks and conquer podium ranks!
          </p>
        </div>

        {/* Action button */}
        <button className="px-4 py-2.5 bg-indigo-500 hover:bg-indigo-650 text-white font-bold text-xs rounded-xl transition flex items-center space-x-1.5 shadow">
          <Swords className="w-4 h-4 text-yellow-400 animate-pulse" />
          <span>Challenge AI Tutor Bot</span>
        </button>
      </div>

      {/* Ranks Podium for first 3 players */}
      <div className="grid grid-cols-3 gap-3 sm:gap-6 items-end pt-10 pb-4 max-w-xl mx-auto">
        
        {/* Podium Item #2 */}
        {topThree[1] && (
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center space-y-2 text-center"
          >
            <div className="relative">
              <img 
                src={topThree[1].avatar} 
                alt={topThree[1].name} 
                className="w-14 h-14 sm:w-16 sm:h-16 rounded-full border-4 border-slate-300 object-cover shadow shadow-slate-100"
              />
              <span className="absolute -bottom-2.5 left-1/2 -translate-x-1/2 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-300 text-slate-800 border border-white">
                Rank 2
              </span>
            </div>
            <div className="pt-2 text-left sm:text-center w-full">
              <span className="font-bold text-slate-800 truncate text-xs sm:text-sm block">
                {topThree[1].name}
              </span>
              <span className="text-[10px] text-slate-400 font-mono block">
                {topThree[1].xp} XP · {topThree[1].level}
              </span>
            </div>
            <div className="h-16 sm:h-20 w-full bg-slate-150 border-t-2 border-slate-200 rounded-t-2xl flex items-center justify-center font-bold text-slate-500">
              🥈
            </div>
          </motion.div>
        )}

        {/* Podium Item #1 (Tallest) */}
        {topThree[0] && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex flex-col items-center space-y-2 text-center"
          >
            <div className="relative">
              {/* Crown indicator */}
              <div className="absolute -top-6 left-1/2 -translate-x-1/2 text-2xl animate-bounce">👑</div>
              <img 
                src={topThree[0].avatar} 
                alt={topThree[0].name} 
                className="w-20 h-20 sm:w-24 sm:h-24 rounded-full border-4 border-amber-400 object-cover shadow shadow-amber-100"
              />
              <span className="absolute -bottom-2.5 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full text-[11px] font-bold bg-amber-400 text-slate-900 border border-white uppercase tracking-wider">
                Rank 1
              </span>
            </div>
            <div className="pt-2 text-left sm:text-center w-full">
              <span className="font-extrabold text-slate-900 truncate text-sm sm:text-base block">
                {topThree[0].name}
              </span>
              <span className="text-[10px] text-amber-600 font-bold font-mono block">
                {topThree[0].xp} XP · {topThree[0].level}
              </span>
            </div>
            <div className="h-24 sm:h-28 w-full bg-amber-50/50 border-t-4 border-amber-400 rounded-t-2xl flex items-center justify-center font-extrabold text-amber-600 shadow shadow-amber-50">
              🥇
            </div>
          </motion.div>
        )}

        {/* Podium Item #3 */}
        {topThree[2] && (
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center space-y-2 text-center"
          >
            <div className="relative">
              <img 
                src={topThree[2].avatar} 
                alt={topThree[2].name} 
                className="w-14 h-14 sm:w-16 sm:h-16 rounded-full border-4 border-amber-650 object-cover shadow shadow-amber-700"
              />
              <span className="absolute -bottom-2.5 left-1/2 -translate-x-1/2 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-650 text-white border border-white">
                Rank 3
              </span>
            </div>
            <div className="pt-2 text-left sm:text-center w-full">
              <span className="font-bold text-slate-800 truncate text-xs sm:text-sm block">
                {topThree[2].name}
              </span>
              <span className="text-[10px] text-slate-400 font-mono block">
                {topThree[2].xp} XP · {topThree[2].level}
              </span>
            </div>
            <div className="h-12 sm:h-16 w-full bg-amber-100/30 border-t-2 border-amber-200 rounded-t-2xl flex items-center justify-center font-bold text-amber-700">
              🥉
            </div>
          </motion.div>
        )}

      </div>

      {/* Main rank roster table */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
        <div className="p-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">
          <span>Learner Roster</span>
          <span>Aggregated Score Level</span>
        </div>

        <div className="divide-y divide-slate-100 text-left">
          {others.map((player) => {
            const isCurrentUser = player.name === currentUserName;
            return (
              <div 
                key={player.name}
                className={`p-4 flex items-center justify-between transition-all ${
                  isCurrentUser ? "bg-indigo-50/50" : "hover:bg-slate-50/40"
                }`}
              >
                <div className="flex items-center space-x-4">
                  {/* Rank circle */}
                  <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                    getMedalColor(player.rank)
                  }`}>
                    {player.rank}
                  </span>

                  {/* Avatar & text details */}
                  <img 
                    src={player.avatar} 
                    alt={player.name} 
                    className="w-10 h-10 rounded-full border object-cover shadow-sm"
                  />
                  <div>
                    <div className="flex items-center space-x-1.5">
                      <span className={`text-sm font-bold ${isCurrentUser ? "text-indigo-900" : "text-slate-800"}`}>
                        {player.name}
                      </span>
                      {isCurrentUser && (
                        <span className="text-[9px] bg-indigo-100 text-indigo-700 font-bold px-1.5 py-0.5 rounded uppercase tracking-widest font-sans">
                          You
                        </span>
                      )}
                    </div>
                    <span className="text-[11px] text-slate-400 font-light leading-none">
                      Level credentials: {player.level}
                    </span>
                  </div>
                </div>

                {/* Score indicators */}
                <div className="text-right">
                  <span className="text-sm font-extrabold text-slate-800 font-sans block">{player.xp} XP</span>
                  <span className="text-[10px] text-slate-400 font-mono block">Status: Online</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
