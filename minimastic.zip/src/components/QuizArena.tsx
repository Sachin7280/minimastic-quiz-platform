import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Sparkles, 
  ArrowRight, 
  Zap, 
  Trophy, 
  Lightbulb, 
  HelpCircle,
  TrendingUp,
  AlertCircle
} from "lucide-react";
import { Quiz, Question } from "../types";

interface QuizArenaProps {
  quiz: Quiz;
  onFinishQuiz: (score: number, totalQuestions: number, studyTimeSeconds: number) => void;
  onCancelQuiz: () => void;
}

export const QuizArena: React.FC<QuizArenaProps> = ({ quiz, onFinishQuiz, onCancelQuiz }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [fillValue, setFillValue] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [score, setScore] = useState(0);
  const [consecutiveCorrect, setConsecutiveCorrect] = useState(0);
  const [consecutiveWrong, setConsecutiveWrong] = useState(0);

  // Stopwatches and Timers
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [questionCountdown, setQuestionCountdown] = useState(45); // 45 seconds per question challenge
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const countdownRef = useRef<NodeJS.Timeout | null>(null);

  // Adaptive difficulty running state
  const [runningDifficulty, setRunningDifficulty] = useState<"Easy" | "Medium" | "Hard" | "Expert">(quiz.difficulty);
  const [adaptiveLog, setAdaptiveLog] = useState<string | null>(null);

  const currentQuestion: Question = quiz.questions[currentIndex];

  // Start general stopwatch
  useEffect(() => {
    timerRef.current = setInterval(() => {
      setElapsedSeconds(prev => prev + 1);
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  // Start question level countdown timer
  useEffect(() => {
    setQuestionCountdown(45);
    
    if (countdownRef.current) clearInterval(countdownRef.current);

    countdownRef.current = setInterval(() => {
      setQuestionCountdown(prev => {
        if (prev <= 1) {
          // Auto submit when time runs out
          handleTimeOut();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (countdownRef.current) clearInterval(countdownRef.current);
    };
  }, [currentIndex]);

  const handleTimeOut = () => {
    if (isSubmitted) return;
    // Auto-fail this question
    setSelectedOption("");
    setIsSubmitted(true);
    setConsecutiveCorrect(0);
    setConsecutiveWrong(prev => prev + 1);
    triggerAdaptiveAdjustment(false);
  };

  const handleSelectOption = (option: string) => {
    if (isSubmitted) return;
    setSelectedOption(option);
  };

  const verifyAndSubmitAnswer = () => {
    if (isSubmitted) return;

    let isCorrect = false;

    if (currentQuestion.type === "Fill in the Blank") {
      const cleanInput = fillValue.trim().toLowerCase();
      const cleanCorrect = currentQuestion.correctAnswer.trim().toLowerCase();
      isCorrect = cleanInput === cleanCorrect || cleanCorrect.includes(cleanInput) && cleanInput.length > 1;
      setSelectedOption(fillValue);
    } else {
      isCorrect = selectedOption === currentQuestion.correctAnswer;
    }

    if (isCorrect) {
      setScore(prev => prev + 1);
      setConsecutiveCorrect(prev => prev + 1);
      setConsecutiveWrong(0);
      triggerAdaptiveAdjustment(true);
    } else {
      setConsecutiveCorrect(0);
      setConsecutiveWrong(prev => prev + 1);
      triggerAdaptiveAdjustment(false);
    }

    setIsSubmitted(true);
    if (countdownRef.current) clearInterval(countdownRef.current);
  };

  // Adaptive learning feedback system
  const triggerAdaptiveAdjustment = (wasCorrect: boolean) => {
    if (wasCorrect) {
      // Correct streak logic
      if (consecutiveCorrect >= 1) {
        if (runningDifficulty === "Easy") {
          setRunningDifficulty("Medium");
          showAdaptiveBanner("✨ Correct Streak! Adaptive Engine increasing difficulty level to Medium! ✨");
        } else if (runningDifficulty === "Medium") {
          setRunningDifficulty("Hard");
          showAdaptiveBanner("🚀 Excellent work! Adaptive Engine shifting next questions to expert Hard level! 🚀");
        } else if (runningDifficulty === "Hard") {
          setRunningDifficulty("Expert");
          showAdaptiveBanner("🔥 UNSTOPPABLE STREAK! Recalibrating arena questions to Expert difficulty! 🔥");
        }
      }
    } else {
      // Wrong streak logic
      if (consecutiveWrong >= 1) {
        if (runningDifficulty === "Expert") {
          setRunningDifficulty("Hard");
          showAdaptiveBanner("⚠️ Hard subject area detected! Re-adjusting adaptive difficulty to standard Hard... ⚠️");
        } else if (runningDifficulty === "Hard") {
          setRunningDifficulty("Medium");
          showAdaptiveBanner("💡 Let's establish confidence first. Adapting questions down to Medium... 💡");
        } else if (runningDifficulty === "Medium") {
          setRunningDifficulty("Easy");
          showAdaptiveBanner("🌱 Calibration assist triggered: setting baseline to Easy difficulty...");
        }
      }
    }
  };

  const showAdaptiveBanner = (message: string) => {
    setAdaptiveLog(message);
    setTimeout(() => {
      setAdaptiveLog(null);
    }, 4500);
  };

  const handleNext = () => {
    if (currentIndex < quiz.questions.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setSelectedOption(null);
      setFillValue("");
      setIsSubmitted(false);
    } else {
      // Completed, push back statistics
      if (timerRef.current) clearInterval(timerRef.current);
      onFinishQuiz(score, quiz.questions.length, elapsedSeconds);
    }
  };

  // Percent completed calculations
  const percentComplete = Math.round(((currentIndex) / quiz.questions.length) * 100);

  return (
    <div className="max-w-3xl mx-auto px-4 py-8 space-y-6" id="minimastic-arena">
      
      {/* Quiz Top Control bar */}
      <div className="flex items-center justify-between bg-white border border-slate-200/60 p-4 rounded-2xl shadow-sm text-sm">
        <div className="text-left">
          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-100 border border-slate-200 uppercase font-semibold text-slate-500">
            {quiz.category}
          </span>
          <h3 className="font-bold text-slate-800 truncate max-w-[200px] sm:max-w-sm mt-1">
            {quiz.title}
          </h3>
        </div>

        {/* Stopwatch & Stats */}
        <div className="flex items-center space-x-4 text-xs font-mono font-bold text-slate-500">
          <div className="flex items-center space-x-1">
            <Clock className="w-4 h-4 text-slate-400" />
            <span>{Math.floor(elapsedSeconds / 60)}m {elapsedSeconds % 60}s</span>
          </div>
          <button 
            onClick={onCancelQuiz}
            className="text-rose-500 hover:text-rose-600 transition"
          >
            Quit
          </button>
        </div>
      </div>

      {/* Progress indicators bar */}
      <div className="space-y-1.5 text-left">
        <div className="flex justify-between items-center text-xs font-semibold text-slate-400 font-mono">
          <span>Question {currentIndex + 1} of {quiz.questions.length}</span>
          <span>{percentComplete}% Completed</span>
        </div>
        <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-indigo-500 to-blue-500 rounded-full transition-all duration-300" 
            style={{ width: `${percentComplete}%` }}
          />
        </div>
      </div>

      {/* Adaptive notifications toast banner */}
      <AnimatePresence>
        {adaptiveLog && (
          <motion.div
            initial={{ opacity: 0, y: -10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            className="p-3 bg-gradient-to-r from-indigo-900 to-slate-900 border border-indigo-700 text-indigo-100 rounded-xl text-center text-xs font-semibold shadow-md flex items-center justify-center space-x-2"
          >
            <Sparkles className="w-4 h-4 text-yellow-400 fill-yellow-400/20 animate-pulse" />
            <span>{adaptiveLog}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Question Card Display Area */}
      <div className="p-6 sm:p-8 bg-white border border-slate-200 rounded-[28px] shadow-md relative overflow-hidden text-left">
        
        {/* Upper metadata details inside card */}
        <div className="flex items-center justify-between mb-6 text-xs text-slate-400 font-mono">
          <div className="flex items-center space-x-1 bg-slate-50 border border-slate-100 px-2.5 py-1 rounded-full">
            <TrendingUp className="w-3 h-3 text-indigo-500" />
            <span>Target Level: {runningDifficulty}</span>
          </div>

          {/* Time Limit Indicator */}
          <div className={`flex items-center space-x-1.5 px-2.5 py-1 rounded-full ${
            questionCountdown <= 10 ? "bg-rose-50 text-rose-600 border border-rose-100" : "bg-slate-50 text-slate-500"
          }`}>
            <Clock className="w-3.5 h-3.5" />
            <span className="font-bold">{questionCountdown}s</span>
          </div>
        </div>

        {/* Question Text */}
        <motion.h4 
          key={currentIndex}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-lg sm:text-xl font-bold text-slate-900 leading-snug"
        >
          {currentQuestion.questionText}
        </motion.h4>

        {/* Inputs selector based on variants types */}
        <div className="mt-8 space-y-3.5">
          <AnimatePresence mode="wait">
            
            {/* MCQ FORMAT */}
            {currentQuestion.type === "MCQ" && (
              <div className="space-y-3">
                {currentQuestion.options.map((option, idx) => {
                  const isSelected = selectedOption === option;
                  const isCorrect = option === currentQuestion.correctAnswer;
                  
                  let optionStyle = "border-slate-200 hover:border-slate-300 hover:bg-slate-50/50 bg-white text-slate-700";
                  if (isSubmitted) {
                    if (isCorrect) {
                      optionStyle = "border-emerald-500 bg-emerald-50/70 text-emerald-900";
                    } else if (isSelected) {
                      optionStyle = "border-rose-450 bg-rose-50/70 text-rose-900";
                    } else {
                      optionStyle = "border-slate-100 bg-slate-50/30 text-slate-400 opacity-60";
                    }
                  } else if (isSelected) {
                    optionStyle = "border-indigo-600 bg-indigo-50/40 text-indigo-900 ring-2 ring-indigo-50";
                  }

                  return (
                    <motion.button
                      key={idx}
                      onClick={() => handleSelectOption(option)}
                      disabled={isSubmitted}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      className={`w-full p-4 rounded-xl border text-left font-medium text-sm transition flex items-center justify-between cursor-pointer ${optionStyle}`}
                    >
                      <div className="flex items-center space-x-3">
                        <span className="text-xs text-slate-400 font-mono">
                          {String.fromCharCode(65 + idx)})
                        </span>
                        <span>{option}</span>
                      </div>

                      {/* Right Indicator Icons */}
                      {isSubmitted && (
                        <div>
                          {isCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-500 fill-emerald-100" />}
                          {!isCorrect && isSelected && <XCircle className="w-5 h-5 text-rose-500 fill-rose-100" />}
                        </div>
                      )}
                    </motion.button>
                  );
                })}
              </div>
            )}

            {/* TRUE / FALSE FORMAT */}
            {currentQuestion.type === "True/False" && (
              <div className="grid grid-cols-2 gap-4">
                {["True", "False"].map((item, idx) => {
                  const isSelected = selectedOption === item;
                  const isCorrect = item === currentQuestion.correctAnswer;

                  let cardStyle = "border-slate-200 hover:border-slate-300 hover:bg-slate-50/50 bg-white text-slate-700";
                  if (isSubmitted) {
                    if (isCorrect) {
                      cardStyle = "border-emerald-500 bg-emerald-50/70 text-emerald-900";
                    } else if (isSelected) {
                      cardStyle = "border-rose-450 bg-rose-50/70 text-rose-900";
                    } else {
                      cardStyle = "border-slate-100 bg-slate-50/30 text-slate-400 opacity-60";
                    }
                  } else if (isSelected) {
                    cardStyle = "border-indigo-600 bg-indigo-50/40 text-indigo-900 ring-2 ring-indigo-50";
                  }

                  return (
                    <motion.button
                      key={item}
                      onClick={() => handleSelectOption(item)}
                      disabled={isSubmitted}
                      className={`p-6 rounded-2xl border text-center font-bold text-lg transition flex flex-col items-center justify-center space-y-2 cursor-pointer ${cardStyle}`}
                    >
                      <span>{item}</span>
                      
                      {isSubmitted && (
                        <div className="mt-2">
                          {isCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-500 fill-emerald-100" />}
                          {!isCorrect && isSelected && <XCircle className="w-5 h-5 text-rose-500 fill-rose-100" />}
                        </div>
                      )}
                    </motion.button>
                  );
                })}
              </div>
            )}

            {/* FILL IN THE BLANK FORMAT */}
            {currentQuestion.type === "Fill in the Blank" && (
              <div className="space-y-4">
                <input
                  type="text"
                  disabled={isSubmitted}
                  required
                  placeholder="Type the precise answer word or phrase here..."
                  value={fillValue}
                  onChange={(e) => setFillValue(e.target.value)}
                  className="w-full px-4 py-3.5 bg-slate-50 border border-slate-200 hover:border-slate-300 focus:bg-white focus:ring-2 focus:ring-indigo-100 focus:border-indigo-500 rounded-xl transition text-sm outline-none font-medium placeholder:text-slate-400"
                />

                {isSubmitted && (
                  <div className={`p-4 rounded-xl border text-sm flex items-start gap-3 text-left ${
                    fillValue.trim().toLowerCase() === currentQuestion.correctAnswer.toLowerCase() 
                      ? "bg-emerald-50 border-emerald-200 text-emerald-800" 
                      : "bg-rose-50 border-rose-200 text-rose-800"
                  }`}>
                    {fillValue.trim().toLowerCase() === currentQuestion.correctAnswer.toLowerCase() ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-500 flex-shrink-0 mt-0.5" />
                    ) : (
                      <XCircle className="w-5 h-5 text-rose-500 flex-shrink-0 mt-0.5" />
                    )}
                    <div>
                      <span className="font-bold">Correct Answer: </span>
                      <span className="font-mono font-semibold bg-white/60 px-2 py-0.5 rounded border ml-1">
                        {currentQuestion.correctAnswer}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            )}

          </AnimatePresence>
        </div>

        {/* Real-time Explanations box showing up on submit */}
        <AnimatePresence>
          {isSubmitted && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              className="mt-6 pt-6 border-t border-slate-100"
            >
              <div className="p-4 bg-indigo-50/40 rounded-2xl border border-indigo-100 text-left space-y-2">
                <div className="flex items-center space-x-1.5 text-indigo-700 font-bold text-xs">
                  <Sparkles className="w-4 h-4 fill-indigo-200 animate-spin-slow text-indigo-500" />
                  <span>Gemini Explanation Analysis</span>
                </div>
                <p className="text-xs sm:text-sm text-slate-650 leading-relaxed font-light">
                  {currentQuestion.explanation}
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Submit & Next Control buttons layout */}
        <div className="mt-8 pt-4 border-t border-slate-100 flex items-center justify-end">
          {!isSubmitted ? (
            <button
              onClick={verifyAndSubmitAnswer}
              disabled={selectedOption === null && currentQuestion.type !== "Fill in the Blank"}
              className={`px-5 py-3 rounded-xl font-bold text-white text-sm transition ${
                (selectedOption === null && currentQuestion.type !== "Fill in the Blank") 
                  ? "bg-slate-200 text-slate-400 cursor-not-allowed" 
                  : "bg-slate-900 hover:bg-slate-800 cursor-pointer shadow"
              }`}
            >
              Check Answer
            </button>
          ) : (
            <button
              onClick={handleNext}
              className="px-5 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-sm transition flex items-center space-x-2 shadow cursor-pointer group"
            >
              <span>{currentIndex === quiz.questions.length - 1 ? "Finish Summary" : "Next Question"}</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition" />
            </button>
          )}
        </div>
      </div>

      {/* Safety warning */}
      <div className="flex items-center space-x-2 text-[10px] text-slate-400 justify-center">
        <AlertCircle className="w-3.5 h-3.5" />
        <span>You cannot modify your selected assessment choices once submitted.</span>
      </div>
    </div>
  );
};
