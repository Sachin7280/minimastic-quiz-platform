import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Sparkles, 
  BrainCircuit, 
  Zap, 
  ChevronRight, 
  CheckCircle, 
  BookOpen, 
  Code, 
  Atom, 
  Compass, 
  Binary, 
  Briefcase, 
  Star, 
  ShieldAlert,
  ArrowRight,
  Target,
  Trophy,
  Users,
  Menu,
  X,
  ShieldCheck,
  CreditCard,
  Building,
  Globe
} from "lucide-react";

interface LandingPageProps {
  onStart: (email?: string) => void;
  onBrowseCategories: () => void;
  onUpgradePro: () => void;
}

export const CATEGORIES_LIST = [
  { name: "Programming", icon: Code, count: 18, rating: "4.9", color: "from-blue-500/10 to-indigo-500/10 text-indigo-600 border-indigo-200/50", desc: "React, Python, Algorithms" },
  { name: "Science", icon: Atom, count: 14, rating: "4.8", color: "from-emerald-500/10 to-teal-500/10 text-teal-600 border-teal-200/50", desc: "Cosmology, Physics, Biology" },
  { name: "Mathematics", icon: Binary, count: 12, rating: "4.7", color: "from-amber-500/10 to-orange-500/10 text-orange-600 border-orange-200/50", desc: "Calculated Logic & Stats" },
  { name: "UPSC", icon: BookOpen, count: 22, rating: "4.9", color: "from-purple-500/10 to-pink-500/10 text-purple-600 border-purple-200/50", desc: "Syllabus Core Polity & History" },
  { name: "History", icon: Compass, count: 15, rating: "4.6", color: "from-rose-500/10 to-red-500/10 text-rose-600 border-rose-200/50", desc: "Sovereignties & Global Events" },
  { name: "Business", icon: Briefcase, count: 9, rating: "4.7", color: "from-cyan-500/10 to-sky-500/10 text-sky-600 border-sky-200/50", desc: "SaaS Systems & Finance" },
];

export const LandingPage: React.FC<LandingPageProps> = ({ 
  onStart, 
  onBrowseCategories,
  onUpgradePro
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50/70 text-slate-800 flex flex-col font-sans" id="minimastic-landing">
      
      {/* Sticky Header with Hamburger Menu */}
      <header className="sticky top-0 z-50 bg-white/85 backdrop-blur-md border-b border-slate-100 px-6 py-4 flex items-center justify-between shadow-xs">
        <div className="flex items-center space-x-2">
          <div className="p-2 sm:p-2.5 bg-gradient-to-tr from-indigo-500 to-blue-500 text-white rounded-xl shadow-md shadow-indigo-200">
            <BrainCircuit className="w-5 h-5 sm:w-6 sm:h-6" />
          </div>
          <span className="text-xl font-bold bg-gradient-to-r from-indigo-600 to-blue-600 bg-clip-text text-transparent tracking-tight">
            Minimastic
          </span>
        </div>

        {/* Desktop Nav Controls */}
        <div className="hidden md:flex items-center space-x-6">
          <a href="#benefits" className="text-sm font-semibold text-slate-500 hover:text-slate-800 transition">Benefits</a>
          <a href="#categories" className="text-sm font-semibold text-slate-500 hover:text-slate-800 transition">Categories</a>
          <a href="#pricing" className="text-sm font-semibold text-slate-500 hover:text-slate-800 transition">Pricing</a>
          
          <span className="h-4 w-px bg-slate-200" />

          <button 
            onClick={() => onStart("guest")} 
            className="text-slate-600 hover:text-indigo-600 text-sm font-medium transition cursor-pointer"
          >
            Guest Login
          </button>
          
          <button 
            onClick={() => onStart()} 
            className="px-4 py-2 bg-slate-900 text-white hover:bg-slate-800 rounded-xl text-sm font-medium transition shadow-sm cursor-pointer"
          >
            Sign In
          </button>
        </div>

        {/* Mobile menu trigger hamburger button */}
        <div className="md:hidden flex items-center">
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="p-2 text-slate-600 hover:text-indigo-600 transition rounded-lg hover:bg-slate-50 focus:outline-none cursor-pointer"
            id="mobile-hamburger-btn"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </header>

      {/* Mobile Drawer Slide-Down */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-b border-slate-100 overflow-hidden z-40 relative flex flex-col px-6 py-4 space-y-4 shadow-lg text-left"
            id="mobile-navigation-drawer"
          >
            <div className="grid grid-cols-2 gap-2 text-xs font-semibold text-slate-500 pb-2 border-b border-slate-100">
              <a 
                href="#benefits" 
                onClick={() => setIsMobileMenuOpen(false)}
                className="p-2 hover:bg-slate-50 rounded-lg"
              >
                ✓ Benefits
              </a>
              <a 
                href="#categories" 
                onClick={() => setIsMobileMenuOpen(false)}
                className="p-2 hover:bg-slate-50 rounded-lg"
              >
                🌍 Categories
              </a>
              <a 
                href="#pricing" 
                onClick={() => setIsMobileMenuOpen(false)}
                className="p-2 hover:bg-slate-50 rounded-lg"
              >
                ₹ Pricing Plans
              </a>
              <button 
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onUpgradePro();
                }}
                className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg text-left font-bold"
              >
                ⚡ UPI Upgrade
              </button>
            </div>

            <div className="flex flex-col space-y-2.5">
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onStart("guest");
                }}
                className="w-full py-3 bg-slate-50 border hover:bg-slate-100 text-slate-700 font-semibold rounded-xl text-center text-sm transition"
              >
                Access Free Sandbox
              </button>
              
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onStart();
                }}
                className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-center text-sm transition shadow-sm"
              >
                Sign In / Authenticate
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Section */}
      <section className="relative px-6 py-14 lg:py-24 max-w-6xl mx-auto flex flex-col items-center text-center">
        {/* Badge */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-700 text-xs font-semibold mb-6 shadow-sm shadow-indigo-50/50"
        >
          <Sparkles className="w-3.5 h-3.5 text-indigo-500 fill-indigo-200 animate-spin-slow" />
          <span>Powered by Google Gemini 3.5 Flash & Instant UPI Settlement</span>
        </motion.div>

        {/* Title */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 leading-tight"
        >
          Create AI-Powered Quizzes <br />
          <span className="bg-gradient-to-r from-indigo-600 via-blue-600 to-emerald-500 bg-clip-text text-transparent">
            in Seconds
          </span>
        </motion.h1>

        {/* Subhead */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mt-6 text-base sm:text-lg text-slate-500 max-w-2xl font-light"
        >
          Minimastic analyzes any topic, paragraph, notes, or prompts to generate custom interactive trivia, real-time feedback, and smart learning plans instantly.
        </motion.p>

        {/* CTA Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-8 flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4 w-full sm:w-auto"
        >
          <button
            onClick={() => onStart()}
            className="px-8 py-4 bg-slate-900 text-white hover:bg-slate-800 font-bold rounded-2xl text-sm transition shadow-lg hover:shadow-xl flex items-center justify-center space-x-2 group cursor-pointer"
          >
            <span>Launch Generator</span>
            <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition" />
          </button>
          
          <button
            onClick={onBrowseCategories}
            className="px-8 py-4 bg-white border border-slate-200 hover:border-slate-300 text-slate-705 font-semibold rounded-2xl text-sm transition shadow-xs flex items-center justify-center space-x-2 cursor-pointer hover:bg-slate-50"
          >
            <span>Explore Seed Topics</span>
          </button>
        </motion.div>

        {/* Quick Social Metrics Indicators */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.4 }}
          className="mt-14 pt-8 border-t border-slate-200/60 w-full grid grid-cols-2 md:grid-cols-4 gap-6 text-slate-500 text-xs sm:text-sm"
        >
          <div className="flex flex-col items-center">
            <span className="text-xl sm:text-2xl font-extrabold text-slate-950">20M+</span>
            <span className="font-light mt-0.5">MCQs Generated</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-xl sm:text-2xl font-extrabold text-slate-950">99.8%</span>
            <span className="font-light mt-0.5">Academic Accuracy</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-xl sm:text-2xl font-extrabold text-slate-950">4.9/5</span>
            <span className="font-light mt-0.5">Direct User Reviews</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-xl sm:text-2xl font-extrabold text-slate-950">₹0 Fee</span>
            <span className="font-light mt-0.5">Sandbox Playground</span>
          </div>
        </motion.div>
      </section>

      {/* Benefit Pillars */}
      <section className="bg-white py-16 px-6 border-y border-slate-100 text-left" id="benefits">
        <div className="max-w-5xl mx-auto">
          <div className="text-center md:text-left mb-12">
            <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full uppercase tracking-wider">
              High Definition Capabilities
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mt-2">
              Transform raw texts into premium assets
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Pillar 1 */}
            <div className="space-y-3.5">
              <div className="p-3 bg-red-50 text-red-500 rounded-xl inline-block">
                <Zap className="w-5 h-5 fill-current" />
              </div>
              <h3 className="text-lg font-bold text-slate-900">Immediate Synthesizer</h3>
              <p className="text-slate-500 text-sm font-light leading-relaxed">
                Provide UPSC, science, or computer science notes. Our parser builds multi-format exams inside a fraction of a single second.
              </p>
            </div>

            {/* Pillar 2 */}
            <div className="space-y-3.5">
              <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl inline-block">
                <BrainCircuit className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-slate-900">Fine-Tuned Difficulty</h3>
              <p className="text-slate-500 text-sm font-light leading-relaxed">
                Choose Easy, Medium, Hard, or Expert scales to train specialized intelligence metrics. Adaptive to your current skill level.
              </p>
            </div>

            {/* Pillar 3 */}
            <div className="space-y-3.5">
              <div className="p-3 bg-emerald-50 text-emerald-500 rounded-xl inline-block">
                <Trophy className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-slate-900">Gamification Engine</h3>
              <p className="text-slate-500 text-sm font-light leading-relaxed">
                Accumulate XP progress levels, hit persistent daily learning streaks, and unlock academic credentials for continuous motivation.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Grid */}
      <section className="py-20 px-6 border-b border-slate-100 text-left bg-slate-50/40" id="categories">
        <div className="max-w-5xl mx-auto">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-12 gap-4">
            <div>
              <span className="text-[10px] font-bold text-teal-600 bg-teal-50 px-2.5 py-1 rounded-full uppercase tracking-wider">
                Examine Seed Concepts
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mt-2">
                Launch pre-made AI syllabus
              </h2>
            </div>
            <button
              onClick={onBrowseCategories}
              className="text-sm font-bold text-indigo-600 hover:text-indigo-800 transition flex items-center space-x-1 cursor-pointer"
            >
              <span>Explore Assessment Hub</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {CATEGORIES_LIST.map((cat, idx) => {
              const IconComp = cat.icon;
              return (
                <div
                  key={idx}
                  onClick={onBrowseCategories}
                  className="p-5 bg-white border border-slate-200/60 rounded-2xl shadow-xs hover:shadow-md hover:border-slate-300 transition-all cursor-pointer flex flex-col justify-between"
                >
                  <div className="flex items-start justify-between">
                    <div className={`p-3 rounded-xl bg-gradient-to-tr ${cat.color}`}>
                      <IconComp className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-mono text-slate-400 font-semibold bg-slate-50 px-2 py-0.5 rounded-md border">
                      {cat.count} syllabus
                    </span>
                  </div>
                  <div className="mt-5 text-left">
                    <h4 className="font-extrabold text-slate-900 text-base">{cat.name}</h4>
                    <p className="text-xs text-slate-400 font-light mt-1">{cat.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Pricing Section - updated to INR and bindings to UPI Checkout */}
      <section className="bg-white py-20 px-6 border-t border-slate-100 text-left" id="pricing">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full uppercase tracking-wider inline-block">
              India Exclusive Pricing Plans
            </span>
            <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight mt-2">
              Refined Plans for High Achievers
            </h2>
            <p className="mt-3 text-slate-500 max-w-md mx-auto text-center text-sm sm:text-base">
              Choose custom study tiers payable directly with any Indian BHIM UPI app.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-3xl mx-auto">
            
            {/* Free Starter */}
            <div className="p-8 rounded-[32px] border border-slate-200 relative bg-white flex flex-col justify-between hover:border-slate-350 transition-all">
              <div>
                <h3 className="text-xl font-bold text-slate-800">Minimastic Starter</h3>
                <p className="mt-2 text-sm text-slate-450 font-light leading-relaxed">
                  Essential quiz training tools for standard academic learners and sandbox testing.
                </p>
                <div className="mt-6 flex items-baseline text-slate-900">
                  <span className="text-4xl font-extrabold tracking-tight font-sans">₹0</span>
                  <span className="ml-1 text-slate-400 font-light text-sm">/ forever</span>
                </div>
                <ul className="mt-8 space-y-4 text-sm text-slate-500">
                  <li className="flex items-center space-x-3">
                    <CheckCircle className="w-4 h-4 text-indigo-500 flex-shrink-0" />
                    <span>Generate up to 10 AI quizzes per day</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <CheckCircle className="w-4 h-4 text-indigo-500 flex-shrink-0" />
                    <span>Real-time adaptive quiz experiences</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <CheckCircle className="w-4 h-4 text-indigo-500 flex-shrink-0" />
                    <span>Basic stats and history analytics</span>
                  </li>
                </ul>
              </div>
              <button 
                onClick={() => onStart("guest")} 
                className="mt-8 w-full py-4 bg-slate-50 hover:bg-slate-100 text-slate-700 font-semibold rounded-2xl text-center text-sm transition cursor-pointer"
              >
                Access Free Sandbox
              </button>
            </div>

            {/* Pro Premium Pay via UPI */}
            <div className="p-8 rounded-[32px] border-2 border-indigo-600 relative bg-indigo-900 text-white flex flex-col justify-between shadow-xl shadow-indigo-100">
              <span className="absolute -top-3.5 right-6 px-3 py-1 bg-gradient-to-r from-emerald-400 to-teal-400 text-slate-900 text-[10px] font-bold uppercase tracking-widest rounded-full border border-teal-200">
                ⭐ Premium Pro
              </span>
              <div>
                <h3 className="text-xl font-bold text-white">Minimastic Professional</h3>
                <p className="mt-2 text-sm text-indigo-200 font-light leading-relaxed">
                  The absolute standard for school teachers and professional syllabus designers desiring maximum power.
                </p>
                <div className="mt-6 flex items-baseline text-white">
                  <span className="text-4xl font-extrabold tracking-tight font-sans">₹299</span>
                  <span className="ml-1 text-indigo-300 font-light text-sm">/ month basis</span>
                </div>
                
                {/* UPI label */}
                <div className="inline-flex items-center space-x-1 mt-2.5 px-2.5 py-1 rounded bg-indigo-950/60 border border-indigo-800 text-[10px] font-mono text-emerald-400 font-semibold">
                  <span>● Direct UPI scan active</span>
                </div>

                <ul className="mt-6 space-y-4 text-sm text-indigo-100">
                  <li className="flex items-center space-x-3">
                    <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    <span>Unlimited AI Quiz generation (No caps)</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    <span>PDF Export summaries & sharing rules</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    <span>AI Study flashcard generation</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    <span>Elite priority response times</span>
                  </li>
                </ul>
              </div>
              
              <button 
                onClick={onUpgradePro} 
                className="mt-8 w-full py-4 bg-white text-indigo-900 hover:bg-indigo-50 font-extrabold rounded-2xl text-sm transition shadow-md shadow-indigo-950/20 cursor-pointer flex items-center justify-center space-x-1.5"
              >
                <span>Start Premium (UPI Pay)</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

          </div>
        </div>
      </section>

      {/* Improved Multi-Column Brand Footer */}
      <footer className="bg-[#0B0F19] text-slate-400 border-t border-slate-900 py-16 px-6 relative mt-auto text-left text-sm">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-10">
          
          {/* Column 1: Info */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center space-x-2 text-white">
              <div className="p-2 bg-gradient-to-r from-indigo-500 to-indigo-600 rounded-xl">
                <BrainCircuit className="w-5 h-5 text-white" />
              </div>
              <span className="text-lg font-bold tracking-tight">Minimastic</span>
            </div>
            <p className="text-slate-400 text-xs sm:text-sm font-light leading-relaxed max-w-sm">
              Minimastic is India's leading lightweight student training platform. We compile complex educational notes, textbooks, and UPSC files into beautifully structured interactive questionnaires instantly via modern large language models.
            </p>
            <div className="flex items-center space-x-3 pt-2 text-[10px] font-bold font-mono text-slate-500">
              <span className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 px-2.5 py-1.5 rounded-lg select-none">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                SECURE UPI PAYMENTS
              </span>
              <span className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 px-2.5 py-1.5 rounded-lg select-none">
                <Building className="w-3.5 h-3.5 text-blue-500" />
                NPCI MERCHANT
              </span>
            </div>
          </div>

          {/* Column 2: Quick Navigation */}
          <div className="md:col-span-4 space-y-4">
            <h5 className="text-white font-bold text-xs uppercase tracking-widest font-mono">Study Hub & Directories</h5>
            <div className="grid grid-cols-1 gap-2.5 text-xs text-slate-400 font-semibold font-sans">
              <a href="#benefits" className="hover:text-white transition">Capability & Benefits Matrix</a>
              <a href="#categories" className="hover:text-white transition">Quick-Launch Seed Categories</a>
              <a href="#pricing" className="hover:text-white transition">Pricing Plans (INR)</a>
              <button onClick={() => onStart("guest")} className="text-left hover:text-white transition cursor-pointer">Access Sandbox Playpen</button>
              <button onClick={onUpgradePro} className="text-indigo-400 text-left hover:text-indigo-300 transition font-bold flex items-center gap-1 cursor-pointer">
                Upgrade Account instantly with UPI <Sparkles className="w-3.5 h-3.5 text-amber-500 inline fill-amber-500/10" />
              </button>
            </div>
          </div>

          {/* Column 3: Legal Compliance & Sandbox Controls */}
          <div className="md:col-span-3 space-y-4">
            <h5 className="text-white font-bold text-xs uppercase tracking-widest font-mono">Legal & Compliance</h5>
            <div className="flex flex-col gap-2.5 text-xs">
              <span className="hover:text-white cursor-pointer transition select-none">Privacy Charter (UID Compliance)</span>
              <span className="hover:text-white cursor-pointer transition select-none">API Agreement & SLA Guidelines</span>
              <span className="hover:text-white cursor-pointer transition select-none">Refund & UPI Billing Settlement</span>
              <p className="text-[10px] text-slate-600 leading-normal font-light pt-2">
                Designed with pride in Bangalore & San Francisco. Indian UPI Clearing node operations active. Licensed under CC Academic Rules.
              </p>
            </div>
          </div>

        </div>

        {/* Lower row details */}
        <div className="max-w-6xl mx-auto mt-12 pt-8 border-t border-slate-900/60 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-slate-600">
          <div>
            © 2026 Minimastic Platform Corporation. All rights reserved. Registered Indian SME.
          </div>
          <div className="flex items-center space-x-1.5">
            <Globe className="w-3.5 h-3.5 text-slate-500" />
            <span>Active Server Node: Bangalore-HQ-Cl1</span>
          </div>
        </div>
      </footer>

    </div>
  );
};
