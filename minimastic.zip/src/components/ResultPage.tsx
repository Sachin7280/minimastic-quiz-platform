import React, { useState } from "react";
import { motion } from "motion/react";
import { 
  Award, 
  Clock, 
  Target, 
  CheckCircle, 
  Share2, 
  Printer, 
  RotateCcw, 
  Sparkles, 
  BookOpen, 
  ChevronDown, 
  ChevronUp, 
  ArrowRight,
  TrendingUp,
  AlertCircle
} from "lucide-react";
import { Quiz, Question } from "../types";

interface ResultPageProps {
  quiz: Quiz;
  score: number;
  totalQuestions: number;
  studyTimeSeconds: number;
  xpEarned: number;
  onRetry: () => void;
  onGoToDashboard: () => void;
  onGenerateSimilar: () => void;
}

export const ResultPage: React.FC<ResultPageProps> = ({
  quiz,
  score,
  totalQuestions,
  studyTimeSeconds,
  xpEarned,
  onRetry,
  onGoToDashboard,
  onGenerateSimilar
}) => {
  const [copied, setCopied] = useState(false);
  const [showReview, setShowReview] = useState(false);

  const accuracy = Math.round((score / totalQuestions) * 100);

  // Score messages
  let titleMessage = "Excellent Performance! 🏆";
  let descMessage = "You have unlocked high-accuracy mastery credentials on this topic.";
  if (accuracy === 100) {
    titleMessage = "PERFECT SCORE! 🔥";
    descMessage = "Flawless analytical capability. You solved every single question correct!";
  } else if (accuracy < 50) {
    titleMessage = "Developing Learner 🌱";
    descMessage = "A solid attempts. Review the AI-generated study analysis below to reinforce your knowledge.";
  } else if (accuracy < 80) {
    titleMessage = "Successful explorer! ⭐";
    descMessage = "Great efforts! Keep taking similar topic assessments to reach scholar level.";
  }

  // Pre-formatted AI Feedback assessment based on final scores
  const getAISpotAnalysis = () => {
    if (accuracy === 100) {
      return `Your intellectual conceptual grasp of ${quiz.category} is absolute. The underlying facts, syntax, and foundational relations are correctly verified. To increase your cognitive speed, start preparing for the "Expert" tier challenge.`;
    }
    if (accuracy >= 70) {
      return `You demonstrate solid mastery in core aspects of ${quiz.title}. Your strong spots reside in deductive definitions, but you can improve speed on complex questions. We suggest reviewing the study guide text list below and repeating with Medium difficulty.`;
    }
    return `An active learning opportunity is highlighted in ${quiz.category}. The Gemini analyzer detects potential struggles with specialized terminology. We recommend reading our pre-seeded educational cards first and trying an Easy tier multi-select challenge.`;
  };

  const handleShare = () => {
    const text = `🏆 I solved the "${quiz.title}" (${quiz.category}) on Minimastic and scored ${score}/${totalQuestions} with ${accuracy}% accuracy! Let's study smarter together!`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handlePrintPdf = () => {
    window.print();
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-8 space-y-8 print:p-0" id="minimastic-result">
      
      {/* Upper score announcement cards */}
      <div className="p-8 bg-gradient-to-tr from-slate-900 to-indigo-950 text-white rounded-[32px] border border-slate-800 shadow-xl relative overflow-hidden text-center print:bg-white print:text-black print:border-none print:shadow-none">
        
        {/* Decorative particles */}
        <div className="absolute top-0 right-0 w-44 h-44 bg-indigo-500/10 rounded-full blur-3xl print:hidden" />
        
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="inline-flex p-4 bg-indigo-500/10 border border-indigo-400/20 text-yellow-400 rounded-full mb-4 animate-float print:hidden"
        >
          <Award className="w-10 h-10 fill-current" />
        </motion.div>

        <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">{titleMessage}</h2>
        <p className="text-slate-300 text-sm mt-2 max-w-md mx-auto font-light leading-relaxed">{descMessage}</p>

        {/* Primary telemetry points */}
        <div className="grid grid-cols-3 gap-4 mt-8 pt-6 border-t border-slate-800/60 max-w-md mx-auto print:border-slate-200">
          
          <div className="text-center">
            <span className="text-[10px] text-slate-400 font-mono uppercase block">Accuracy</span>
            <span className="text-xl sm:text-2xl font-extrabold text-emerald-400 mt-1 block font-sans">{accuracy}%</span>
          </div>

          <div className="text-center border-x border-slate-800/60 print:border-slate-200">
            <span className="text-[10px] text-slate-400 font-mono uppercase block">Time Speed</span>
            <span className="text-xl sm:text-2xl font-extrabold text-indigo-300 mt-1 block font-sans">
              {Math.floor(studyTimeSeconds / 60)}m {studyTimeSeconds % 60}s
            </span>
          </div>

          <div className="text-center">
            <span className="text-[10px] text-slate-400 font-mono uppercase block">Reward</span>
            <span className="text-xl sm:text-2xl font-extrabold text-amber-400 mt-1 block font-sans">+{xpEarned} XP</span>
          </div>

        </div>
      </div>

      {/* Gemini AI Performance Assessment */}
      <div className="p-6 bg-indigo-50/50 border border-indigo-100 rounded-3xl text-left space-y-3 print:border-slate-200">
        <div className="flex items-center space-x-2 text-indigo-700 font-bold text-sm">
          <Sparkles className="w-4 h-4 fill-indigo-200 animate-spin-slow text-indigo-500" />
          <span>Gemini AI Performance Analysis</span>
        </div>
        <p className="text-sm text-slate-650 leading-relaxed font-light">
          {getAISpotAnalysis()}
        </p>
      </div>

      {/* Control Actions buttons grouping */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 print:hidden">
        
        <button
          onClick={onRetry}
          className="p-3.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold rounded-2xl text-xs sm:text-sm transition flex flex-col items-center justify-center space-y-1 cursor-pointer"
        >
          <RotateCcw className="w-4 h-4" />
          <span>Retry Assessment</span>
        </button>

        <button
          onClick={handlePrintPdf}
          className="p-3.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold rounded-2xl text-xs sm:text-sm transition flex flex-col items-center justify-center space-y-1 cursor-pointer"
        >
          <Printer className="w-4 h-4" />
          <span>Print Study Guide</span>
        </button>

        <button
          onClick={handleShare}
          className={`p-3.5 border font-bold rounded-2xl text-xs sm:text-sm transition flex flex-col items-center justify-center space-y-1 cursor-pointer ${
            copied 
              ? "bg-emerald-50 border-emerald-300 text-emerald-800" 
              : "bg-white border-slate-200 hover:bg-slate-50 text-slate-700"
          }`}
        >
          <Share2 className="w-4 h-4" />
          <span>{copied ? "Copied!" : "Share Results"}</span>
        </button>

        <button
          onClick={onGenerateSimilar}
          className="p-3.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-2xl text-xs sm:text-sm transition flex flex-col items-center justify-center space-y-1 cursor-pointer shadow-sm shadow-indigo-100"
        >
          <Sparkles className="w-4 h-4 text-amber-300 fill-amber-300/30" />
          <span>Generate Similar</span>
        </button>

      </div>

      {/* Collapsible Study Questions Review List */}
      <div className="space-y-4">
        <button
          onClick={() => setShowReview(!showReview)}
          className="w-full p-5 bg-white border border-slate-200 rounded-2xl flex items-center justify-between text-left font-bold text-slate-800 hover:bg-slate-50 transition print:hidden"
        >
          <div className="flex items-center space-x-2">
            <BookOpen className="w-5 h-5 text-indigo-500" />
            <span>Interactive Study Review Guide</span>
          </div>
          {showReview ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
        </button>

        {/* Collapsible details or print force display */}
        <div className={`space-y-4 ${showReview ? "block" : "hidden print:block"}`}>
          <div className="text-left mb-6 font-semibold text-slate-400 text-xs uppercase tracking-wider font-mono hidden print:block">
            Quiz Study Guide: {quiz.title} · Category: {quiz.category}
          </div>

          {quiz.questions.map((q, idx) => {
            return (
              <div 
                key={q.id}
                className="p-6 bg-white border border-slate-200 rounded-2xl text-left space-y-4"
              >
                <div className="flex items-center space-x-2 text-xs font-mono font-bold text-slate-400">
                  <span className="px-2 py-0.5 rounded-full bg-slate-50 border">No.{idx+1}</span>
                  <span className="px-2 py-0.5 rounded-full bg-slate-50 border uppercase">{q.type}</span>
                </div>

                <h5 className="font-bold text-slate-800 text-sm leading-snug">{q.questionText}</h5>

                {/* Choices list for static layout */}
                {q.options.length > 0 && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-medium">
                    {q.options.map((opt) => {
                      const isCorrect = opt === q.correctAnswer;
                      return (
                        <div 
                          key={opt}
                          className={`p-2.5 rounded-lg border flex items-center justify-between ${
                            isCorrect 
                              ? "bg-emerald-50/50 border-emerald-200 text-emerald-800 font-semibold" 
                              : "bg-slate-50/50 border-slate-100 text-slate-500"
                          }`}
                        >
                          <span>{opt}</span>
                          {isCorrect && <CheckCircle className="w-4 h-4 text-emerald-550 fill-emerald-100 flex-shrink-0" />}
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Correct Answers & Explanations */}
                <div className="pt-3 border-t border-slate-50 space-y-2.5">
                  <div className="text-xs text-slate-500 flex items-baseline">
                    <span className="font-bold text-slate-700 flex-shrink-0">Answer Solution:</span>
                    <span className="font-mono bg-slate-100 border px-2 py-0.5 rounded ml-2 text-slate-700 font-semibold select-all text-[11px]">
                      {q.correctAnswer}
                    </span>
                  </div>

                  <div className="p-3 bg-indigo-50/20 border border-slate-100 rounded-xl text-xs leading-relaxed font-light text-slate-600">
                    <span className="font-semibold text-indigo-700 text-[10px] font-mono block mb-1">AI ANALYSIS DETAILS:</span>
                    {q.explanation}
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      </div>

      {/* Bottom redirection controls widget */}
      <div className="flex items-center justify-between border-t border-slate-200/50 pt-6 print:hidden">
        <button
          onClick={onGoToDashboard}
          className="text-slate-500 hover:text-slate-800 text-sm font-semibold transition"
        >
          Back to Generator Hub
        </button>

        <button
          onClick={onGoToDashboard}
          className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-xs sm:text-sm transition flex items-center space-x-1 shadow"
        >
          <span>Study Dashboard</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

    </div>
  );
};
