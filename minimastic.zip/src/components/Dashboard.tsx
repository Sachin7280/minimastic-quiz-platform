import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Trophy, 
  Flame, 
  TrendingUp, 
  Plus, 
  Sparkles, 
  Lightbulb, 
  Layers, 
  HelpCircle, 
  Search, 
  Clock, 
  AlignLeft, 
  FolderMinus, 
  FileText,
  UserCheck,
  ChevronRight,
  BookOpen,
  History,
  Compass,
  Code,
  Atom,
  Binary,
  Briefcase,
  AlertTriangle,
  RotateCcw
} from "lucide-react";
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip,
  PieChart,
  Pie,
  Cell
} from "recharts";
import { UserProfile, Recommendation, Quiz } from "../types";
import { CATEGORIES_LIST } from "./LandingPage";

interface DashboardProps {
  profile: UserProfile;
  recommendations: Recommendation[];
  onGenerateQuiz: (params: {
    topic: string;
    mode: "topic" | "notes";
    difficulty: "Easy" | "Medium" | "Hard" | "Expert";
    numQuestions: number;
    type: "MCQ" | "True/False" | "Fill in the Blank";
  }) => void;
  isLoading: boolean;
  onSelectCategory: (name: string) => void;
  onResetProgress: () => void;
  onUpgradePro: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  profile,
  recommendations,
  onGenerateQuiz,
  isLoading,
  onSelectCategory,
  onResetProgress,
  onUpgradePro
}) => {
  const [activeTab, setActiveTab] = useState<"generate" | "history" | "stats">("generate");
  
  // Quiz parameters state
  const [mode, setMode] = useState<"topic" | "notes">("topic");
  const [topic, setTopic] = useState("");
  const [notes, setNotes] = useState("");
  const [difficulty, setDifficulty] = useState<"Easy" | "Medium" | "Hard" | "Expert">("Medium");
  const [numQuestions, setNumQuestions] = useState<number>(5);
  const [quizType, setQuizType] = useState<"MCQ" | "True/False" | "Fill in the Blank">("MCQ");

  // Local query state for preseeded categories
  const [searchQuery, setSearchQuery] = useState("");

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalTopic = mode === "topic" 
      ? topic 
      : notes.slice(0, 100) + "... " + "Notes Source";

    if (mode === "topic" && !topic.trim()) return;
    if (mode === "notes" && !notes.trim()) return;

    onGenerateQuiz({
      topic: mode === "topic" ? topic : `Custom study notes: ${notes}`,
      mode,
      difficulty,
      numQuestions,
      type: quizType
    });
  };

  // Prepare chart data chronologically
  const sortedHistory = [...profile.history].reverse();
  const performanceData = sortedHistory.map((item, idx) => ({
    name: `Quiz ${idx + 1}`,
    accuracy: item.accuracy,
    score: item.score,
    xp: item.xpEarned,
  }));

  // Fallback if history is empty
  const defaultPerformanceData = [
    { name: "Syllabus 1", accuracy: 70, score: 3, xp: 30 },
    { name: "Syllabus 2", accuracy: 90, score: 4, xp: 40 },
    { name: "Today's Target", accuracy: 100, score: 5, xp: 100 }
  ];

  const chartData = performanceData.length > 0 ? performanceData : defaultPerformanceData;

  // Prepare data for category distribution
  const categoryCounts: Record<string, number> = {};
  profile.history.forEach((h) => {
    categoryCounts[h.category] = (categoryCounts[h.category] || 0) + 1;
  });

  const pieData = Object.entries(categoryCounts).map(([name, value]) => ({
    name,
    value
  }));

  const COLORS = ["#6366F1", "#10B981", "#F59E0B", "#EF4444", "#EC4899", "#8B5CF6", "#14B8A6"];

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-8" id="minimastic-dashboard">
      
      {/* Upper Action Banner - Quick Welcome */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-6 bg-gradient-to-r from-indigo-900 to-indigo-950 text-white p-6 sm:p-8 rounded-[32px] border border-indigo-800 shadow-xl shadow-indigo-100">
        <div className="flex items-center space-x-4 text-left">
          <img 
            src={profile.avatar} 
            alt={profile.name} 
            className="w-16 h-16 rounded-full border-2 border-indigo-400 object-cover shadow-inner"
          />
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-xl sm:text-2xl font-bold tracking-tight">Welcome, {profile.name}!</h2>
              <span className="text-[10px] bg-indigo-500 text-indigo-50 font-medium px-2 py-0.5 rounded-full uppercase tracking-widest border border-indigo-400">
                {profile.level}
              </span>
            </div>
            <p className="text-indigo-200 text-xs sm:text-sm font-light mt-1">
              {profile.email} · Keep pushing your learning boundaries today!
            </p>
          </div>
        </div>

        {/* Level bar & XP tracker */}
        <div className="w-full md:w-auto bg-indigo-950/60 p-4 rounded-2xl border border-indigo-800 flex flex-col justify-center min-w-[240px]">
          <div className="flex justify-between items-center text-xs text-indigo-200 font-mono font-medium mb-1.5">
            <span>Level Progress</span>
            <span>{profile.xp} XP</span>
          </div>
          <div className="h-2 w-full bg-indigo-950 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-emerald-400 to-teal-400 rounded-full transition-all duration-500" 
              style={{ width: `${Math.min((profile.xp % 300) / 3, 100)}%` }} // arbitrary level increment helper
            />
          </div>
          <div className="text-[10px] text-indigo-300 font-light mt-1 text-right">
            {300 - (profile.xp % 300)} XP remaining until next benchmark
          </div>
        </div>
      </div>

      {/* Primary Statistics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div className="p-5 rounded-2xl border border-slate-200/60 bg-white shadow-sm flex items-center space-x-4">
          <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl">
            <Trophy className="w-5 h-5" />
          </div>
          <div className="text-left">
            <div className="text-xs text-slate-400 font-mono font-semibold uppercase tracking-wider">Total XP</div>
            <div className="text-2xl font-extrabold text-slate-800 mt-0.5">{profile.xp}</div>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="p-5 rounded-2xl border border-slate-200/60 bg-white shadow-sm flex items-center space-x-4">
          <div className="p-3 bg-red-50 text-red-500 rounded-xl animate-pulse">
            <Flame className="w-5 h-5 fill-red-400" />
          </div>
          <div className="text-left">
            <div className="text-xs text-slate-400 font-mono font-semibold uppercase tracking-wider">Streak</div>
            <div className="text-2xl font-extrabold text-slate-800 mt-0.5">{profile.streak} Days</div>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="p-5 rounded-2xl border border-slate-200/60 bg-white shadow-sm flex items-center space-x-4">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div className="text-left">
            <div className="text-xs text-slate-400 font-mono font-semibold uppercase tracking-wider">Accuracy</div>
            <div className="text-2xl font-extrabold text-slate-800 mt-0.5">{profile.averageAccuracy}%</div>
          </div>
        </div>

        {/* Metric 4 */}
        <div className="p-5 rounded-2xl border border-slate-200/60 bg-white shadow-sm flex items-center space-x-4">
          <div className="p-3 bg-amber-50 text-amber-500 rounded-xl">
            <Clock className="w-5 h-5" />
          </div>
          <div className="text-left">
            <div className="text-xs text-slate-400 font-mono font-semibold uppercase tracking-wider">Study Time</div>
            <div className="text-xl sm:text-2xl font-extrabold text-slate-800 mt-0.5">
              {Math.round(profile.studyTimeSeconds / 60)} mins
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs for Hub Content */}
      <div className="flex border-b border-slate-200 gap-6 text-sm font-semibold">
        <button
          onClick={() => setActiveTab("generate")}
          className={`pb-3 relative transition flex items-center space-x-2 ${
            activeTab === "generate" ? "text-indigo-600" : "text-slate-400 hover:text-slate-600"
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>AI Generator Hub</span>
          {activeTab === "generate" && (
            <motion.div layoutId="dash-tabs" className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-600" />
          )}
        </button>

        <button
          onClick={() => setActiveTab("history")}
          className={`pb-3 relative transition flex items-center space-x-2 ${
            activeTab === "history" ? "text-indigo-600" : "text-slate-400 hover:text-slate-600"
          }`}
        >
          <History className="w-4 h-4" />
          <span>Quiz Attempt History ({profile.history.length})</span>
          {activeTab === "history" && (
            <motion.div layoutId="dash-tabs" className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-600" />
          )}
        </button>

        <button
          onClick={() => setActiveTab("stats")}
          className={`pb-3 relative transition flex items-center space-x-2 ${
            activeTab === "stats" ? "text-indigo-600" : "text-slate-400 hover:text-slate-600"
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>Analytics Reports</span>
          {activeTab === "stats" && (
            <motion.div layoutId="dash-tabs" className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-600" />
          )}
        </button>
      </div>

      {/* Main Container Render Section based on tabs */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 text-left">
        
        {/* LEFT COMPONENT COLUMN */}
        <div className="lg:col-span-8 space-y-8">
          <AnimatePresence mode="wait">
            
            {/* GENERATE TAB */}
            {activeTab === "generate" && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="space-y-8"
                key="tab-generate"
              >
                {/* Form Generator Panel */}
                <div className="relative p-6 sm:p-8 bg-white border border-slate-200/50 rounded-3xl shadow-md overflow-hidden">
                  
                  {/* Subtle decorative background glow */}
                  <div className="absolute -top-12 -right-12 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl" />
                  
                  <div className="flex items-center space-x-2 mb-6">
                    <Sparkles className="w-5 h-5 text-indigo-500" />
                    <h3 className="text-xl font-bold text-slate-800">Prompt a New Quiz Challenge</h3>
                  </div>

                  {/* Mode Selector Toggle buttons */}
                  <div className="grid grid-cols-2 bg-slate-100 p-1 rounded-xl mb-6 text-sm font-semibold max-w-[320px]">
                    <button
                      type="button"
                      onClick={() => setMode("topic")}
                      className={`py-2 rounded-lg flex items-center justify-center space-x-2 transition ${
                        mode === "topic" ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-800"
                      }`}
                    >
                      <Search className="w-4 h-4" />
                      <span>By Subject/Topic</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setMode("notes")}
                      className={`py-2 rounded-lg flex items-center justify-center space-x-2 transition ${
                        mode === "notes" ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-800"
                      }`}
                    >
                      <FileText className="w-4 h-4" />
                      <span>Custom Notes</span>
                    </button>
                  </div>

                  {/* Submit Form */}
                  <form onSubmit={handleFormSubmit} className="space-y-6">
                    {mode === "topic" ? (
                      <div className="space-y-2">
                        <label className="text-sm font-semibold text-slate-700">Enter quiz topic or special custom prompt</label>
                        <div className="relative">
                          <input
                            type="text"
                            required
                            placeholder="e.g., React Hooks, UPSC Indian Polity, Black Hole physics..."
                            value={topic}
                            onChange={(e) => setTopic(e.target.value)}
                            className="w-full px-4 py-3.5 pl-11 bg-slate-50 border border-slate-200 hover:border-slate-300 focus:bg-white focus:ring-2 focus:ring-indigo-100 focus:border-indigo-500 rounded-xl transition text-sm outline-none placeholder:text-slate-400"
                          />
                          <Search className="absolute left-4 top-4 w-4 h-4 text-slate-400" />
                        </div>
                        <div className="flex flex-wrap gap-1.5 mt-2">
                          <span className="text-[10px] text-slate-400 self-center">Try prompt suggestions:</span>
                          {["JavaScript Trivia", "World Capitals", "Modern Physics", "Indian Constitution"].map((s) => (
                            <button
                              key={s}
                              type="button"
                              onClick={() => setTopic(s)}
                              className="text-[10px] bg-slate-100 hover:bg-slate-200 text-slate-600 px-2.5 py-1 rounded-full border border-slate-200 transition font-mono"
                            >
                              +{s}
                            </button>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <label className="text-sm font-semibold text-slate-700">Paste your raw document notes/paragraphs below</label>
                        <textarea
                          required
                          rows={4}
                          placeholder="Drag and drop or copy paste lectures, PDF summary snippets, or reference notes. Gemini will structure questions based purely on this transcript..."
                          value={notes}
                          onChange={(e) => setNotes(e.target.value)}
                          className="w-full px-4 py-3.5 bg-slate-50 border border-slate-200 hover:border-slate-300 focus:bg-white focus:ring-2 focus:ring-indigo-100 focus:border-indigo-500 rounded-xl transition text-sm outline-none placeholder:text-slate-400 leading-relaxed resize-none"
                        />
                        <p className="text-[10px] text-slate-400 font-light">
                          Perfect for digesting school notes, online syllabus articles, or textbook screenshots.
                        </p>
                      </div>
                    )}

                    {/* Parameter Toggles */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
                      
                      {/* Difficulty */}
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Difficulty Level</label>
                        <select
                          value={difficulty}
                          onChange={(e) => setDifficulty(e.target.value as any)}
                          className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium hover:border-slate-300 transition focus:outline-none"
                        >
                          <option value="Easy">Easy (100 XP baseline)</option>
                          <option value="Medium">Medium (Regular challenge)</option>
                          <option value="Hard">Hard (Expert syllabus)</option>
                          <option value="Expert">Expert (Ultra-adaptive rules)</option>
                        </select>
                      </div>

                      {/* Count */}
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">No. of Questions</label>
                        <div className="flex items-center space-x-1.5">
                          {[5, 10, 15].map((cnt) => (
                            <button
                              key={cnt}
                              type="button"
                              onClick={() => setNumQuestions(cnt)}
                              className={`flex-1 py-2 text-xs font-semibold rounded-xl border transition ${
                                numQuestions === cnt 
                                  ? "bg-slate-900 border-slate-900 text-white shadow-sm" 
                                  : "bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-600"
                              }`}
                            >
                              {cnt} MCQs
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Question formats */}
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Question Style</label>
                        <select
                          value={quizType}
                          onChange={(e) => setQuizType(e.target.value as any)}
                          className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium hover:border-slate-300 transition focus:outline-none"
                        >
                          <option value="MCQ">Standard MCQs</option>
                          <option value="True/False">True / False Trivia</option>
                          <option value="Fill in the Blank">Fill-in-the-Blank</option>
                        </select>
                      </div>
                    </div>

                    {/* Form submit button */}
                    <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                      <div className="text-xs text-slate-400 font-mono hidden sm:block">
                        Est. Time: ~{numQuestions * 35} seconds
                      </div>
                      <button
                        type="submit"
                        disabled={isLoading}
                        className={`w-full sm:w-auto px-6 py-3.5 rounded-2xl font-bold text-white transition flex items-center justify-center space-x-2 group shadow-lg ${
                          isLoading 
                            ? "bg-indigo-400 cursor-not-allowed" 
                            : "bg-indigo-600 hover:bg-indigo-700 shadow-indigo-150 cursor-pointer"
                        }`}
                      >
                        {isLoading ? (
                          <>
                            <div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                            <span>Gymnastics with Gemini...</span>
                          </>
                        ) : (
                          <>
                            <Sparkles className="w-4 h-4 animate-spin-slow text-amber-300 fill-amber-300/30" />
                            <span>Assemble AI Quiz Challenge</span>
                            <ChevronRight className="w-4 h-4 group-hover:translate-x-1" />
                          </>
                        )}
                      </button>
                    </div>
                  </form>
                </div>

                {/* Categories Showcase with local filtering */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-lg font-bold text-slate-800">Quick-Launch Seed Categories</h4>
                    <div className="relative text-xs w-[180px] sm:w-[240px]">
                      <input
                        type="text"
                        placeholder="Search categories..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full pl-8 pr-3 py-1.5 bg-slate-100 hover:bg-slate-200/50 rounded-lg outline-none font-medium transition"
                      />
                      <Search className="absolute left-2.5 top-2.5 w-3 h-3 text-slate-400" />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {CATEGORIES_LIST.filter(cat => cat.name.toLowerCase().includes(searchQuery.toLowerCase())).map((cat, i) => {
                      const IconComp = cat.icon;
                      return (
                        <div
                          key={i}
                          onClick={() => onSelectCategory(cat.name)}
                          className="p-5 rounded-2xl border border-slate-200 bg-white hover:border-slate-300 shadow-sm hover:shadow transition flex justify-between items-center group cursor-pointer"
                        >
                          <div className="flex items-center space-x-4">
                            <div className={`p-3 rounded-xl bg-gradient-to-tr ${cat.color}`}>
                              <IconComp className="w-5 h-5" />
                            </div>
                            <div className="text-left">
                              <span className="text-sm font-bold text-slate-800 group-hover:text-indigo-600 transition">
                                {cat.name}
                              </span>
                              <div className="text-xs text-slate-400 mt-0.5">{cat.desc}</div>
                            </div>
                          </div>
                          <ChevronRight className="w-4 h-4 text-slate-300 group-hover:translate-x-1 transition group-hover:text-indigo-500" />
                        </div>
                      );
                    })}
                  </div>
                </div>

              </motion.div>
            )}

            {/* ATTEMPT HISTORY TAB */}
            {activeTab === "history" && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="space-y-4"
                key="tab-history"
              >
                {profile.history.length === 0 ? (
                  <div className="p-12 text-center bg-white border border-slate-200/50 rounded-3xl">
                    <History className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                    <h3 className="text-lg font-bold text-slate-700">No trivia attempts yet!</h3>
                    <p className="text-slate-400 text-sm mt-1 max-w-sm mx-auto font-light">
                      Create your very first AI Quiz using the generation hub above to build dynamic statistics.
                    </p>
                    <button
                      onClick={() => setActiveTab("generate")}
                      className="mt-6 px-5 py-2.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold rounded-xl text-sm transition"
                    >
                      Prompt First Quiz Now
                    </button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {profile.history.map((record) => (
                      <div 
                        key={record.id}
                        className="p-5 rounded-2xl border border-slate-200 bg-white hover:shadow-sm transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-left"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center space-x-2">
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-100 border border-slate-200 font-bold text-slate-500 uppercase">
                              {record.category}
                            </span>
                            <span className="text-[10px] font-sans px-2 py-0.5 rounded-full bg-pink-50 border border-pink-100 font-medium text-pink-600">
                              {record.difficulty}
                            </span>
                          </div>
                          <h4 className="text-base font-bold text-slate-850 tracking-tight">
                            {record.quizTitle}
                          </h4>
                          <span className="text-xs text-slate-400 font-mono">
                            Completed at: {new Date(record.completedAt).toLocaleDateString()} · {new Date(record.completedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>

                        <div className="flex items-center space-x-6 w-full sm:w-auto justify-between sm:justify-end border-t sm:border-t-0 pt-3 sm:pt-0 border-slate-50">
                          <div className="text-left sm:text-right">
                            <div className="text-xs text-slate-400 font-mono">Accuracy Summary</div>
                            <div className="flex items-baseline space-x-1">
                              <span className="text-lg font-extrabold text-slate-800">
                                {record.score}/{record.totalQuestions}
                              </span>
                              <span className="text-xs text-emerald-500 font-bold">
                                ({record.accuracy}%)
                              </span>
                            </div>
                          </div>

                          <div className="bg-amber-50 border border-amber-100 px-3 py-1.5 rounded-xl text-center min-w-[70px]">
                            <span className="text-[10px] text-amber-500 font-mono uppercase font-bold block leading-none">XP Saved</span>
                            <span className="text-base font-extrabold text-amber-600">+{record.xpEarned}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </motion.div>
            )}

            {/* ANALYTICS REPORTS TAB */}
            {activeTab === "stats" && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="space-y-8"
                key="tab-stats"
              >
                {/* Visual Charts Block */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  {/* Chart 1: Accuracy Trends */}
                  <div className="p-6 rounded-3xl border border-slate-200/60 bg-white shadow-sm text-left">
                    <h4 className="text-base font-bold text-slate-800 mb-4">Historical Accuracy Percentages</h4>
                    <div className="h-64 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                          <defs>
                            <linearGradient id="colorAcc" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#6366F1" stopOpacity={0.2}/>
                              <stop offset="95%" stopColor="#6366F1" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <XAxis dataKey="name" stroke="#94A3B8" fontSize={10} tickLine={false} />
                          <YAxis stroke="#94A3B8" fontSize={10} tickLine={false} domain={[0, 100]} />
                          <Tooltip contentStyle={{ fontSize: '11px', borderRadius: '12px' }} />
                          <Area type="monotone" dataKey="accuracy" stroke="#6366F1" strokeWidth={2.5} fillOpacity={1} fill="url(#colorAcc)" name="Accuracy %" />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Chart 2: Category distribution study progress */}
                  <div className="p-6 rounded-3xl border border-slate-200/60 bg-white shadow-sm text-left">
                    <h4 className="text-base font-bold text-slate-800 mb-4">Topic Category Distribution</h4>
                    {pieData.length === 0 ? (
                      <div className="h-64 flex flex-col items-center justify-center text-slate-400 font-light text-xs">
                        <FolderMinus className="w-8 h-8 text-slate-300 mb-2" />
                        <span>Not enough distinct historical categories. Attempt a quiz!</span>
                      </div>
                    ) : (
                      <div className="h-64 w-full flex flex-col sm:flex-row items-center justify-center">
                        <div className="h-44 w-44">
                          <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                              <Pie
                                data={pieData}
                                cx="50%"
                                cy="50%"
                                innerRadius={45}
                                outerRadius={65}
                                paddingAngle={3}
                                dataKey="value"
                              >
                                {pieData.map((entry, index) => (
                                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                              </Pie>
                              <Tooltip contentStyle={{ fontSize: '11px', borderRadius: '12px' }} />
                            </PieChart>
                          </ResponsiveContainer>
                        </div>
                        <div className="flex-1 space-y-1.5 mt-4 sm:mt-0 sm:ml-6 text-xs text-left font-sans font-medium">
                          {pieData.map((item, index) => (
                            <div key={item.name} className="flex items-center space-x-2">
                              <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: COLORS[index % COLORS.length] }} />
                              <span className="text-slate-600 truncate max-w-[120px]">{item.name}</span>
                              <span className="text-slate-400 font-mono text-[10px]">({item.value})</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Achievements Showcase Section */}
                <div className="space-y-4">
                  <h4 className="text-lg font-bold text-slate-800">Earned Credentials & Achievements</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {profile.achievements.map((ach) => {
                      return (
                        <div
                          key={ach.id}
                          className={`p-5 rounded-2xl border transition flex items-start space-x-4 text-left ${
                            ach.unlocked 
                              ? "bg-gradient-to-tr from-slate-900 to-indigo-950 text-white border-slate-800 shadow-md"
                              : "bg-white border-slate-200 text-slate-400 opacity-60"
                          }`}
                        >
                          <div className={`p-3 rounded-xl ${
                            ach.unlocked ? "bg-indigo-500/20 text-yellow-400" : "bg-slate-50 text-slate-300"
                          }`}>
                            <Trophy className="w-5 h-5 fill-current" />
                          </div>
                          <div>
                            <span className="text-sm font-bold tracking-tight block">
                              {ach.title}
                            </span>
                            <span className={`text-xs mt-1 block font-light leading-snug ${
                              ach.unlocked ? "text-slate-300" : "text-slate-400"
                            }`}>
                              {ach.description}
                            </span>
                            {ach.unlocked && ach.unlockedAt && (
                              <span className="text-[9px] text-emerald-400 font-mono mt-2 block font-medium">
                                Unlocked: {new Date(ach.unlockedAt).toLocaleDateString()}
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </motion.div>
            )}

          </AnimatePresence>
        </div>

        {/* RIGHT SIDEBAR COLUMN */}
        <div className="lg:col-span-4 space-y-6">

          {/* Pro Tier Upgrade Banner */}
          {!profile.isPro ? (
            <div className="p-6 bg-gradient-to-br from-indigo-900 via-indigo-950 to-slate-900 border border-slate-800 rounded-3xl text-left space-y-4 shadow-lg relative overflow-hidden">
              <div className="absolute top-3 right-3 text-amber-300">
                <Sparkles className="w-4 h-4 animate-pulse" />
              </div>
              <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest bg-emerald-950/60 border border-emerald-800 px-2.5 py-0.5 rounded-full mt-1 inline-block">
                ⚡ UPI PREMIUM SIGNUP
              </span>
              <h4 className="font-extrabold text-white text-base tracking-tight leading-snug">
                Activate Professional Syllabus Generators
              </h4>
              <p className="text-xs text-indigo-200/70 leading-relaxed font-light">
                Unlock unlimited AI quiz prompts, direct high-speed PDFs export, and full expert questions! Pay securely using standard UPI.
              </p>
              <div className="pt-2 flex items-baseline justify-between gap-2">
                <div>
                  <span className="text-white text-lg font-extrabold">₹299</span>
                  <span className="text-[10px] text-indigo-300 ml-1">/ lifetime</span>
                </div>
                <button
                  onClick={onUpgradePro}
                  className="px-4 py-2 bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-500 hover:to-teal-500 text-slate-950 font-bold text-xs rounded-xl transition shadow shadow-teal-950/20 flex items-center space-x-1 cursor-pointer"
                >
                  <span>Go Pro (UPI)</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ) : (
            <div className="p-6 bg-indigo-50 border border-indigo-100 rounded-3xl text-left space-y-3 relative overflow-hidden shadow">
              <div className="absolute top-3 right-3 text-indigo-600 animate-spin-slow">
                <Sparkles className="w-4 h-4 fill-current" />
              </div>
              <span className="text-[10px] font-bold text-indigo-700 uppercase tracking-widest bg-indigo-100/60 border border-indigo-200 px-2.5 py-0.5 rounded-full">
                ✓ PRO ACTIVE
              </span>
              <h4 className="font-extrabold text-indigo-950 text-base">
                Professional Level Active
              </h4>
              <p className="text-xs text-slate-600 leading-normal font-light">
                Your premium account features direct unlimited syllabus generation. Thank you for supporting Minimastic!
              </p>
            </div>
          )}

          {/* Quick-Action User Setup Reset */}
          <div className="p-5 rounded-2xl border border-rose-150/50 bg-rose-50/20 text-left space-y-3">
            <div className="flex items-center space-x-2 text-rose-800 font-bold text-sm">
              <AlertTriangle className="w-4 h-4 text-rose-600" />
              <span>Sandbox Controls</span>
            </div>
            <p className="text-xs text-slate-500 leading-snug">
              To test leveling up, unlocking items or reset baseline scores, you can trigger a full profile wipe instantly.
            </p>
            <button
              onClick={() => {
                if (window.confirm("Restore profile back to initial 0 XP? This deletes mock quiz histories.")) {
                  onResetProgress();
                }
              }}
              className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-semibold text-xs rounded-lg transition-all flex items-center space-x-1 shadow-sm leading-none"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Wipe Sandbox Progress</span>
            </button>
          </div>
          
          {/* AI Recommended Quizzes Feed */}
          <div className="p-6 bg-gradient-to-br from-indigo-50 to-blue-50/50 border border-indigo-100 rounded-3xl text-left space-y-4">
            <div className="flex items-center space-x-2">
              <Lightbulb className="w-5 h-5 text-indigo-500 fill-indigo-200" />
              <h4 className="font-bold text-slate-800 text-base leading-none">Smart Lesson Plan</h4>
            </div>

            <p className="text-xs text-slate-500 leading-relaxed font-light">
              We analyze category coverage in your history and generate priority flashcard subjects below.
            </p>

            <div className="space-y-3 pt-2">
              {recommendations.slice(0, 2).map((rec, i) => {
                return (
                  <div
                    key={i}
                    onClick={() => {
                      setTopic(rec.category);
                      setMode("topic");
                      setDifficulty(rec.suggestedDifficulty);
                      setQuizType("MCQ");
                      setActiveTab("generate");
                    }}
                    className="p-4 rounded-2xl bg-white border border-indigo-100 hover:border-indigo-300 transition-all cursor-pointer group shadow-sm text-left"
                  >
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-600 font-bold uppercase tracking-wider">
                      {rec.category}
                    </span>
                    <p className="text-xs font-bold text-slate-800 mt-2 tracking-tight group-hover:text-indigo-600 transition leading-snug">
                      {rec.reason}
                    </p>
                    <div className="mt-3 pt-2.5 border-t border-slate-50 flex items-center justify-between text-[10px] text-slate-400 font-mono font-medium">
                      <span>Target: {rec.suggestedDifficulty}</span>
                      <span className="text-indigo-500 flex items-center">
                        Synthesize <ChevronRight className="w-3 h-3 ml-0.5 group-hover:translate-x-1 transition" />
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Duolingo Inspired Tips of the Day widget */}
          <div className="p-6 bg-white border border-slate-200/60 rounded-3xl text-left space-y-3">
            <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-100">
              Weekly Tip
            </span>
            <h5 className="font-bold text-slate-800 text-sm tracking-tight leading-snug">
              Leverage Text Synthesis for exact exams!
            </h5>
            <p className="text-xs text-slate-400 font-light leading-relaxed">
              If studying for a highly customized exam like UPSC or CSE, copy exact article paragraphs in the "Custom Notes" tab. This narrows the Gemini model focus for ultra-relevant questions.
            </p>
          </div>

        </div>
      </div>
    </div>
  );
};
