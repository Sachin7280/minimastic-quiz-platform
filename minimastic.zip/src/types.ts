export interface Question {
  id: number;
  questionText: string;
  type: "MCQ" | "True/False" | "Fill in the Blank";
  options: string[];
  correctAnswer: string;
  explanation: string;
  difficultySuggestion: "Easy" | "Medium" | "Hard";
}

export interface Quiz {
  title: string;
  category: string;
  difficulty: "Easy" | "Medium" | "Hard" | "Expert";
  questions: Question[];
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  unlockedAt?: string;
}

export interface QuizHistoryItem {
  id: string;
  quizTitle: string;
  category: string;
  difficulty: string;
  score: number;
  totalQuestions: number;
  accuracy: number;
  xpEarned: number;
  completedAt: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatar: string;
  xp: number;
  level: string;
  streak: number;
  quizzesTaken: number;
  totalQuestionsSolved: number;
  averageAccuracy: number;
  studyTimeSeconds: number;
  isPro?: boolean;
  achievements: Achievement[];
  history: QuizHistoryItem[];
}

export interface LeaderboardItem {
  name: string;
  level: string;
  xp: number;
  avatar: string;
  rank: number;
  dynamic?: boolean;
}

export interface Recommendation {
  category: string;
  reason: string;
  suggestedDifficulty: "Easy" | "Medium" | "Hard";
  estimatedTime: string;
}
