import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  BrainCircuit, 
  Trophy, 
  User, 
  LayoutDashboard, 
  Sparkles, 
  History, 
  HelpCircle, 
  BookOpen, 
  ChevronRight,
  Flame,
  Atom,
  LogOut,
  Swords,
  Layers,
  ArrowRight,
  Menu,
  X,
  CreditCard,
  ShieldCheck
} from "lucide-react";
import { UserProfile, Quiz, Recommendation, LeaderboardItem } from "./types";
import { LandingPage } from "./components/LandingPage";
import { Dashboard } from "./components/Dashboard";
import { QuizArena } from "./components/QuizArena";
import { ResultPage } from "./components/ResultPage";
import { LeaderboardPage } from "./components/LeaderboardPage";
import { UpiPaymentModal } from "./components/UpiPaymentModal";

export default function App() {
  const [currentView, setCurrentView] = useState<"landing" | "dashboard" | "leaderboard" | "quiz" | "result">("landing");
  
  // App state
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [leaderboard, setLeaderboard] = useState<LeaderboardItem[]>([]);
  const [activeQuiz, setActiveQuiz] = useState<Quiz | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isUpiModalOpen, setIsUpiModalOpen] = useState(false);
  const [isInnerMenuOpen, setIsInnerMenuOpen] = useState(false);

  // Stats recorded for result screen transition
  const [lastScore, setLastScore] = useState(0);
  const [lastTotal, setLastTotal] = useState(0);
  const [lastTimeSeconds, setLastTimeSeconds] = useState(0);
  const [lastXpEarned, setLastXpEarned] = useState(0);

  // Synchronize base endpoints on load
  const loadAppTelemetry = async () => {
    try {
      const pRes = await fetch("/api/auth/profile");
      const pData = await pRes.json();
      if (pData.success) {
        setProfile(pData.profile);
      }

      const rRes = await fetch("/api/quiz/recommend");
      const rData = await rRes.json();
      if (rData.success) {
        setRecommendations(rData.recommendations);
      }

      const lRes = await fetch("/api/leaderboard");
      const lData = await lRes.json();
      if (lData.success) {
        setLeaderboard(lData.leaderboard);
      }
    } catch (err) {
      console.error("Failed to load backend telemetry data, loading fallback simulation:", err);
      // In case of any network sync delays, initialize default profile offline in state
      setProfile({
        id: "offline-user",
        name: "Sachin Banana",
        email: "majorsachinbananahskillbased@gmail.com",
        avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200",
        xp: 150,
        level: "Learner",
        streak: 3,
        quizzesTaken: 1,
        totalQuestionsSolved: 5,
        averageAccuracy: 80,
        studyTimeSeconds: 240,
        achievements: [],
        history: []
      });
    }
  };

  useEffect(() => {
    loadAppTelemetry();
  }, []);

  const handleStartLanding = (email?: string) => {
    // Navigate straight to dashboard central hub
    setCurrentView("dashboard");
  };

  const handleGenerateQuiz = async (params: {
    topic: string;
    mode: "topic" | "notes";
    difficulty: "Easy" | "Medium" | "Hard" | "Expert";
    numQuestions: number;
    type: "MCQ" | "True/False" | "Fill in the Blank";
  }) => {
    setIsGenerating(true);
    setErrorMessage(null);
    try {
      const response = await fetch("/api/quiz/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(params)
      });
      const data = await response.json();
      if (data.success && data.quiz) {
        setActiveQuiz(data.quiz);
        setCurrentView("quiz");
      } else {
        throw new Error(data.error || "Failed to generate standard interactive quiz.");
      }
    } catch (err: any) {
      console.error("Quiz compilation error:", err);
      setErrorMessage(err.message || "Network timeout or Gemini context overfill. Please check API settings or try another topic.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSelectQuickCategory = (categoryName: string) => {
    handleGenerateQuiz({
      topic: categoryName,
      mode: "topic",
      difficulty: "Medium",
      numQuestions: 5,
      type: "MCQ"
    });
  };

  const handleFinishArena = async (score: number, totalQuestions: number, studyTimeSeconds: number) => {
    if (!activeQuiz) return;
    
    setIsGenerating(true);
    try {
      // Submit results to update database stats
      const response = await fetch("/api/quiz/submit-result", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: activeQuiz.title,
          category: activeQuiz.category,
          difficulty: activeQuiz.difficulty,
          score,
          totalQuestions,
          studyTimeSeconds
        })
      });
      
      const data = await response.json();
      if (data.success) {
        setProfile(data.profile);
        setLastScore(score);
        setLastTotal(totalQuestions);
        setLastTimeSeconds(studyTimeSeconds);
        setLastXpEarned(data.xpEarned);
        setCurrentView("result");
        
        // Refresh leaderboard in background
        const lRes = await fetch("/api/leaderboard");
        const lData = await lRes.json();
        if (lData.success) {
          setLeaderboard(lData.leaderboard);
        }
      }
    } catch (err) {
      console.error("Failed to submit quiz summary results:", err);
      // Offline fallback calculation
      setLastScore(score);
      setLastTotal(totalQuestions);
      setLastTimeSeconds(studyTimeSeconds);
      setLastXpEarned(score * 10);
      setCurrentView("result");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleResetSandbox = async () => {
    try {
      const response = await fetch("/api/auth/reset", { method: "POST" });
      const data = await response.json();
      if (data.success) {
        setProfile(data.profile);
        loadAppTelemetry();
      }
    } catch (err) {
      console.error("Reset error:", err);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50/50 flex flex-col font-sans selection:bg-indigo-100 selection:text-indigo-900" id="minimastic-root">
      
      {/* Dynamic Navbar when logged inside */}
      {currentView !== "landing" && (
        <>
          <header className="bg-white/85 backdrop-blur-md sticky top-0 z-40 border-b border-slate-100 px-6 py-4 flex items-center justify-between shadow-xs">
            <div 
              onClick={() => {
                if (currentView === "quiz" && !window.confirm("Abandon current quiz progress? Your running details will not be saved.")) return;
                setCurrentView("landing");
              }}
              className="flex items-center space-x-2 cursor-pointer group"
            >
              <div className="p-2 bg-gradient-to-tr from-indigo-500 to-blue-500 text-white rounded-xl shadow shadow-indigo-100 transition group-hover:scale-105">
                <BrainCircuit className="w-5 h-5" />
              </div>
              <span className="text-lg font-extrabold bg-gradient-to-r from-slate-900 to-indigo-950 bg-clip-text text-transparent tracking-tight">
                Minimastic
              </span>
            </div>

            {/* Desktop Navigation Menu Links */}
            <nav className="hidden md:flex items-center space-x-1 sm:space-x-4 text-xs sm:text-sm font-semibold">
              <button
                onClick={() => {
                  if (currentView === "quiz" && !window.confirm("Abandon current quiz progress? Your running details will not be saved.")) return;
                  setCurrentView("dashboard");
                }}
                className={`px-3 py-2 rounded-xl transition flex items-center space-x-1.5 ${
                  currentView === "dashboard" || currentView === "result"
                    ? "bg-indigo-50 text-indigo-700"
                    : "text-slate-500 hover:text-slate-800 hover:bg-slate-50/80"
                }`}
              >
                <LayoutDashboard className="w-4 h-4" />
                <span>Assessment Hub</span>
              </button>

              <button
                onClick={() => {
                  if (currentView === "quiz" && !window.confirm("Abandon current quiz progress?")) return;
                  setCurrentView("leaderboard");
                }}
                className={`px-3 py-2 rounded-xl transition flex items-center space-x-1.5 ${
                  currentView === "leaderboard"
                    ? "bg-indigo-50 text-indigo-700"
                    : "text-slate-500 hover:text-slate-800 hover:bg-slate-50/80"
                }`}
              >
                <Trophy className="w-4 h-4 text-yellow-500" />
                <span>Rank Arena</span>
              </button>
            </nav>

            {/* Desktop Mini Widget indicating XP / Streaks */}
            {profile && (
              <div className="hidden md:flex items-center space-x-3 text-xs sm:text-sm">
                <div className="flex items-center space-x-1.5 text-amber-600 font-mono font-bold bg-amber-50 px-2.5 py-1.5 rounded-xl border border-amber-100">
                  <Trophy className="w-3.5 h-3.5 fill-current text-amber-500" />
                  <span>{profile.xp} XP</span>
                </div>

                <div className="flex items-center space-x-1 font-bold text-red-500 bg-red-50 px-2.5 py-1.5 rounded-xl border border-red-100">
                  <Flame className="w-3.5 h-3.5 fill-current animate-pulse" />
                  <span>{profile.streak} Days</span>
                </div>

                {!profile.isPro && (
                  <button
                    onClick={() => setIsUpiModalOpen(true)}
                    className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl transition shadow flex items-center space-x-1 cursor-pointer"
                  >
                    <span>Upgrade Pro</span>
                  </button>
                )}

                <button 
                  onClick={() => {
                    if (window.confirm("Sign out back to landing directory?")) {
                      setCurrentView("landing");
                    }
                  }}
                  className="p-2 hover:bg-slate-100 rounded-xl transition text-slate-400 hover:text-slate-700 cursor-pointer"
                  title="Sign out"
                >
                  <LogOut className="w-4 h-4px" />
                </button>
              </div>
            )}

            {/* Mobile Header elements (Sticky Hamburger + Streak) */}
            <div className="md:hidden flex items-center space-x-2">
              {profile && (
                <div className="flex items-center space-x-1 font-bold text-red-505 bg-red-50 px-2.5 py-1 rounded-lg border border-red-100 text-xs select-none">
                  <Flame className="w-3.5 h-3.5 fill-current" />
                  <span>{profile.streak}</span>
                </div>
              )}
              
              <button
                onClick={() => setIsInnerMenuOpen(!isInnerMenuOpen)}
                className="p-2 text-slate-600 hover:bg-slate-50 rounded-lg flex items-center justify-center cursor-pointer"
              >
                {isInnerMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </header>

          {/* Mobile Inner Dropdown Drawer */}
          <AnimatePresence>
            {isInnerMenuOpen && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="md:hidden bg-white border-b border-slate-100 overflow-hidden relative z-30 px-6 py-4 flex flex-col space-y-3.5 shadow-md text-left"
              >
                <div className="flex flex-col space-y-1.5 border-b pb-3.5 border-slate-100">
                  <button
                    onClick={() => {
                      setIsInnerMenuOpen(false);
                      setCurrentView("dashboard");
                    }}
                    className={`w-full py-2.5 px-3.5 rounded-xl transition font-bold text-sm text-left flex items-center space-x-2 cursor-pointer ${
                      currentView === "dashboard" || currentView === "result"
                        ? "bg-indigo-50 text-indigo-700"
                        : "text-slate-600 hover:bg-slate-50"
                    }`}
                  >
                    <LayoutDashboard className="w-4 h-4" />
                    <span>AI Assessment Hub</span>
                  </button>

                  <button
                    onClick={() => {
                      setIsInnerMenuOpen(false);
                      setCurrentView("leaderboard");
                    }}
                    className={`w-full py-2.5 px-3.5 rounded-xl transition font-bold text-sm text-left flex items-center space-x-2 cursor-pointer ${
                      currentView === "leaderboard"
                        ? "bg-indigo-50 text-indigo-700"
                        : "text-slate-600 hover:bg-slate-50"
                    }`}
                  >
                    <Trophy className="w-4 h-4 text-amber-500 fill-amber-500/15" />
                    <span>Rank Gamification Arena</span>
                  </button>
                </div>

                {profile && (
                  <div className="space-y-3 font-sans">
                    <div className="flex items-center justify-between text-xs font-semibold px-1">
                      <span className="text-slate-400">Streak Level Status</span>
                      <span className="text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100 font-mono font-bold">
                        {profile.xp} XP Accumulation
                      </span>
                    </div>

                    {!profile.isPro ? (
                      <button
                        onClick={() => {
                          setIsInnerMenuOpen(false);
                          setIsUpiModalOpen(true);
                        }}
                        className="w-full py-3 bg-gradient-to-r from-indigo-600 to-indigo-700 text-white hover:opacity-95 font-bold text-xs rounded-xl transition flex items-center justify-center space-x-1.5 shadow shadow-indigo-150 cursor-pointer"
                      >
                        <CreditCard className="w-4 h-4" />
                        <span>Upgrade to Premium Pro (₹299 Basis)</span>
                      </button>
                    ) : (
                      <div className="p-3 bg-indigo-50 border border-indigo-150 rounded-xl text-indigo-700 text-xs font-bold text-center">
                        ✓ PRO PREMIUM MEMBER ACTIVE 🌟
                      </div>
                    )}

                    <button
                      onClick={() => {
                        setIsInnerMenuOpen(false);
                        if (window.confirm("Sign out back to landing?")) {
                          setCurrentView("landing");
                        }
                      }}
                      className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-center text-xs transition flex items-center justify-center space-x-1"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Log Out out of System</span>
                    </button>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </>
      )}

      {/* Global Error toast */}
      <AnimatePresence>
        {errorMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-rose-50 border-b border-rose-100 px-6 py-3 flex items-center justify-between text-rose-800 text-xs sm:text-sm font-medium z-50 text-left"
          >
            <div className="flex items-center space-x-2">
              <span className="font-bold">Error:</span>
              <span>{errorMessage}</span>
            </div>
            <button 
              onClick={() => setErrorMessage(null)} 
              className="text-rose-500 hover:text-rose-700 font-bold ml-4 font-mono text-sm leading-none"
            >
              Close
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Primary content router flow */}
      <main className="flex-grow">
        <AnimatePresence mode="wait">
          {currentView === "landing" && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              key="view-landing"
            >
              <LandingPage 
                onStart={handleStartLanding}
                onBrowseCategories={() => setCurrentView("dashboard")}
                onUpgradePro={() => setIsUpiModalOpen(true)}
              />
            </motion.div>
          )}

          {currentView === "dashboard" && profile && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              key="view-dashboard"
            >
              <Dashboard 
                profile={profile}
                recommendations={recommendations}
                onGenerateQuiz={handleGenerateQuiz}
                isLoading={isGenerating}
                onSelectCategory={handleSelectQuickCategory}
                onResetProgress={handleResetSandbox}
                onUpgradePro={() => setIsUpiModalOpen(true)}
              />
            </motion.div>
          )}

          {currentView === "quiz" && activeQuiz && (
            <motion.div
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              key="view-quiz-arena"
            >
              <QuizArena 
                quiz={activeQuiz}
                onFinishQuiz={handleFinishArena}
                onCancelQuiz={() => {
                  if (window.confirm("Quit quiz session? Your running scores will be discarded.")) {
                    setCurrentView("dashboard");
                  }
                }}
              />
            </motion.div>
          )}

          {currentView === "result" && activeQuiz && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              key="view-result"
            >
              <ResultPage 
                quiz={activeQuiz}
                score={lastScore}
                totalQuestions={lastTotal}
                studyTimeSeconds={lastTimeSeconds}
                xpEarned={lastXpEarned}
                onRetry={() => {
                  // restart with currently cached activeQuiz
                  setCurrentView("quiz");
                }}
                onGoToDashboard={() => setCurrentView("dashboard")}
                onGenerateSimilar={() => {
                  handleGenerateQuiz({
                    topic: activeQuiz.title + " related topics",
                    mode: "topic",
                    difficulty: activeQuiz.difficulty,
                    numQuestions: activeQuiz.questions.length,
                    type: activeQuiz.questions[0].type
                  });
                }}
              />
            </motion.div>
          )}

          {currentView === "leaderboard" && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              key="view-leaderboard"
            >
              <LeaderboardPage 
                leaderboard={leaderboard}
                currentUserName={profile?.name || "Sachin Banana"}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <UpiPaymentModal 
        isOpen={isUpiModalOpen} 
        onClose={() => setIsUpiModalOpen(false)} 
        onPaymentSuccess={(updatedProfile) => {
          setProfile(updatedProfile);
          // Auto route to inner dashboard if guest upgrades!
          setCurrentView("dashboard");
          loadAppTelemetry();
        }} 
        amount={299} 
      />
    </div>
  );
}
