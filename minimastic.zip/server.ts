import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import * as dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize GoogleGenAI client lazy-style
let aiClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI | null {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (key) {
      aiClient = new GoogleGenAI({
        apiKey: key,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
    } else {
      console.warn("GEMINI_API_KEY is not defined. Falling back to preseeded offline quizzes.");
    }
  }
  return aiClient;
}

// Preseeded Offline Quizzes for fallback and instant play
const PRESEEDED_QUIZZES: Record<string, any[]> = {
  "programming": [
    {
      title: "React Essentials Quiz",
      category: "Programming",
      difficulty: "Medium",
      questions: [
        {
          id: 1,
          questionText: "Which React hook is used to perform side effects in functional components?",
          type: "MCQ",
          options: ["useState", "useContext", "useEffect", "useReducer"],
          correctAnswer: "useEffect",
          explanation: "useEffect lets you perform side effects in functional components, such as data fetching, subscriptions, or manually changing the DOM.",
          difficultySuggestion: "Easy"
        },
        {
          id: 2,
          questionText: "State updates in React are direct and synchronous.",
          type: "True/False",
          options: ["True", "False"],
          correctAnswer: "False",
          explanation: "React state updates are batched and scheduled, making them asynchronous for performance optimization.",
          difficultySuggestion: "Medium"
        },
        {
          id: 3,
          questionText: "What is the name of the syntax extension used in React that allows writing HTML-like code in JavaScript?",
          type: "Fill in the Blank",
          options: [],
          correctAnswer: "JSX",
          explanation: "JSX stands for JavaScript XML. It allows us to write HTML elements in JavaScript and place them in the DOM without any createElement() methods.",
          difficultySuggestion: "Easy"
        },
        {
          id: 4,
          questionText: "Which hook should be used to memoize a computed value between re-renders?",
          type: "MCQ",
          options: ["useMemo", "useCallback", "useRef", "useState"],
          correctAnswer: "useMemo",
          explanation: "useMemo returns a memoized value, recalculating it only when one of its dependency values changes.",
          difficultySuggestion: "Medium"
        },
        {
          id: 5,
          questionText: "React uses a virtual representation of the DOM to optimize rendering performance. This is called the ________ DOM.",
          type: "Fill in the Blank",
          options: [],
          correctAnswer: "Virtual",
          explanation: "React creates a lightweight in-memory cache of the actual DOM, which is updated and synced efficiently, called the Virtual DOM.",
          difficultySuggestion: "Medium"
        }
      ]
    }
  ],
  "technology": [
    {
      title: "Cloud Computing & Internet History",
      category: "Technology",
      difficulty: "Medium",
      questions: [
        {
          id: 1,
          questionText: "What does SaaS stand for in cloud computing?",
          type: "MCQ",
          options: ["Software as a Service", "System as a Service", "Storage as a Solution", "Security as a System"],
          correctAnswer: "Software as a Service",
          explanation: "SaaS stands for Software as a Service, allowing users to connect to and use cloud-based apps over the Internet.",
          difficultySuggestion: "Easy"
        },
        {
          id: 2,
          questionText: "HTTP is secure by default.",
          type: "True/False",
          options: ["True", "False"],
          correctAnswer: "False",
          explanation: "HTTP is clear-text and unencrypted. HTTPS adds TLS/SSL encryption for secure transmission.",
          difficultySuggestion: "Easy"
        },
        {
          id: 3,
          questionText: "Who is credited with inventing the World Wide Web in 1989?",
          type: "MCQ",
          options: ["Tim Berners-Lee", "Bill Gates", "Steve Jobs", "Alan Turing"],
          correctAnswer: "Tim Berners-Lee",
          explanation: "Tim Berners-Lee wrote the first web server and browser, launching the World Wide Web in 1989.",
          difficultySuggestion: "Medium"
        }
      ]
    }
  ],
  "science": [
    {
      title: "Cosmology and Physics trivia",
      category: "Science",
      difficulty: "Hard",
      questions: [
        {
          id: 1,
          questionText: "What is the speed of light in a vacuum approximately (in kilometers per second)?",
          type: "MCQ",
          options: ["150,000 km/s", "300,000 km/s", "450,000 km/s", "600,000 km/s"],
          correctAnswer: "300,000 km/s",
          explanation: "Light travels at approximately 299,792 kilometers per second in a vacuum, which is rounded to 300,000 km/s.",
          difficultySuggestion: "Medium"
        },
        {
          id: 2,
          questionText: "Water is more dense as a solid (ice) than as a liquid.",
          type: "True/False",
          options: ["True", "False"],
          correctAnswer: "False",
          explanation: "Water is unusual because its solid state (ice) is less dense than its liquid state. This is why ice floats.",
          difficultySuggestion: "Easy"
        }
      ]
    }
  ],
  "general knowledge": [
    {
      title: "World Landmarks & Capitals",
      category: "General Knowledge",
      difficulty: "Easy",
      questions: [
        {
          id: 1,
          questionText: "What is the capital of Japan?",
          type: "MCQ",
          options: ["Kyoto", "Osaka", "Tokyo", "Hiroshima"],
          correctAnswer: "Tokyo",
          explanation: "Tokyo is the official economic and political capital of Japan, holding the metropolitan government.",
          difficultySuggestion: "Easy"
        },
        {
          id: 2,
          questionText: "Which ocean is the largest on planet Earth?",
          type: "MCQ",
          options: ["Atlantic Ocean", "Indian Ocean", "Pacific Ocean", "Arctic Ocean"],
          correctAnswer: "Pacific Ocean",
          explanation: "The Pacific Ocean is the largest and deepest of Earth's oceanic divisions, extending from the Arctic to the Southern Ocean.",
          difficultySuggestion: "Easy"
        }
      ]
    }
  ],
};

// Default user profile matching requirements
let userProfile: UserProfile = {
  id: "user-default",
  name: "Sachin Banana",
  email: "majorsachinbananahskillbased@gmail.com",
  avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200",
  xp: 120,
  level: "Learner",
  streak: 3,
  quizzesTaken: 2,
  totalQuestionsSolved: 8,
  averageAccuracy: 88,
  studyTimeSeconds: 420,
  isPro: false,
  achievements: [
    {
      id: "first-quiz",
      title: "First Quiz Completed",
      description: "Successfully submit your very first academic quiz.",
      icon: "Award",
      unlocked: true,
      unlockedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: "century-mark",
      title: "Century Solver",
      description: "Solve over 100 questions to prove persistent learning.",
      icon: "ShieldAlert",
      unlocked: false,
    },
    {
      id: "undefeated",
      title: "Perfect Accuracy",
      description: "Achieve a perfect 100% score on any generated quiz.",
      icon: "Sparkles",
      unlocked: false,
    },
    {
      id: "dedicated",
      title: "Dedicated Streak",
      description: "Maintain a daily quiz solving streak of 3 or more days.",
      icon: "Flame",
      unlocked: true,
      unlockedAt: new Date().toISOString(),
    },
    {
      id: "category-master",
      title: "Polymath",
      description: "Complete quizzes in 3 or more distinct major categories.",
      icon: "Layers",
      unlocked: false,
    },
  ],
  history: [
    {
      id: "h-1",
      quizTitle: "Basic HTML & CSS Core Fundamentals",
      category: "Programming",
      difficulty: "Easy",
      score: 4,
      totalQuestions: 4,
      accuracy: 100,
      xpEarned: 40,
      completedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: "h-2",
      quizTitle: "General Astronomy Trivia",
      category: "Science",
      difficulty: "Medium",
      score: 3,
      totalQuestions: 4,
      accuracy: 75,
      xpEarned: 30,
      completedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    }
  ],
};

interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatar: string;
  xp: number;
  level: string;
  streak: number;
  quizzesTaken: number;
  totalQuestionsSolved: number;
  averageAccuracy: number;
  studyTimeSeconds: number;
  achievements: {
    id: string;
    title: string;
    description: string;
    icon: string;
    unlocked: boolean;
    unlockedAt?: string;
  }[];
  history: {
    id: string;
    quizTitle: string;
    category: string;
    difficulty: string;
    score: number;
    totalQuestions: number;
    accuracy: number;
    xpEarned: number;
    completedAt: string;
  }[];
  isPro?: boolean;
}

// Static mock leaderboard for gamification
const LEADERBOARD_USERS = [
  { name: "Siddharth Jain", level: "Grand Master", xp: 3240, avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=100", rank: 1, dynamic: false },
  { name: "Rohini Sen", level: "Master", xp: 1980, avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=100", rank: 2, dynamic: false },
  { name: "Sachin Banana", level: "Learner", xp: 120, avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=100", rank: 3, dynamic: true },
  { name: "Aditya Roy", level: "Scholar", xp: 840, avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=100", rank: 4, dynamic: false },
  { name: "Priya Sharma", level: "Explorer", xp: 510, avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=100", rank: 5, dynamic: false },
];

/**
 * REST Endpoint: Get user profile
 */
app.get("/api/auth/profile", (req, res) => {
  res.json({ success: true, profile: userProfile });
});

/**
 * REST Endpoint: Upgrade User Profile to Pro status via Simulated UPI validation
 */
app.post("/api/auth/upgrade-pro", (req, res) => {
  const { reference, upiId } = req.body;
  userProfile.isPro = true;
  userProfile.xp += 150; // Give extra XP as premium reward

  // Update level based on new XP if necessary
  if (userProfile.xp > 2000) userProfile.level = "Grand Master Pro Expert";
  else if (userProfile.xp > 1000) userProfile.level = "Master Pro Expert";
  else if (userProfile.xp > 600) userProfile.level = "Scholar Pro Expert";
  else if (userProfile.xp > 300) userProfile.level = "Explorer Pro Expert";
  else userProfile.level = "Pro Expert Leader";

  // Unlock appropriate achievement
  userProfile.achievements = userProfile.achievements.map((ach) => {
    if (ach.id === "century-mark") {
      return { ...ach, unlocked: true, unlockedAt: new Date().toISOString() };
    }
    return ach;
  });

  console.log(`[UPI ACCOUNT MANAGER] User active subscription upgraded via UPI. Reference: ${reference}, ID: ${upiId}`);
  res.json({ success: true, profile: userProfile });
});

/**
 * REST Endpoint: Reset profile for resetting values to standard level
 */
app.post("/api/auth/reset", (req, res) => {
  userProfile = {
    id: "user-default",
    name: "Sachin Banana",
    email: "majorsachinbananahskillbased@gmail.com",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200",
    xp: 0,
    level: "Beginner",
    streak: 1,
    quizzesTaken: 0,
    totalQuestionsSolved: 0,
    averageAccuracy: 0,
    studyTimeSeconds: 0,
    isPro: false,
    achievements: userProfile.achievements.map((item) => ({ ...item, unlocked: false, unlockedAt: undefined })),
    history: [],
  };
  res.json({ success: true, profile: userProfile });
});

/**
 * REST Endpoint: Get current Leaderboard status
 */
app.get("/api/leaderboard", (req, res) => {
  // Map static and update dynamic ranking based on current XP
  const updated = LEADERBOARD_USERS.map((u) => {
    if (u.dynamic) {
      return { ...u, xp: userProfile.xp, level: userProfile.level };
    }
    return u;
  }).sort((a, b) => b.xp - a.xp);

  const parsed = updated.map((u, i) => ({ ...u, rank: i + 1 }));
  res.json({ success: true, leaderboard: parsed });
});

/**
 * REST Endpoint: Provide AI recommendations based on category frequency in history
 */
app.get("/api/quiz/recommend", (req, res) => {
  // Analyze categories already practiced
  const practiced = userProfile.history.map((h) => h.category.toLowerCase());
  const allCategories = [
    "Technology", "Programming", "Science", "Mathematics", "History", 
    "Geography", "Current Affairs", "Business", "Aptitude", "English"
  ];
  const unused = allCategories.filter((c) => !practiced.includes(c.toLowerCase()));
  const targetCategory = unused.length > 0 ? unused[0] : "Programming";

  res.json({
    success: true,
    recommendations: [
      {
        category: targetCategory,
        reason: practiced.length === 0 
          ? "Perfect starting point for newcomers." 
          : `Explore ${targetCategory} to broaden your multi-category credentials!`,
        suggestedDifficulty: userProfile.xp > 500 ? "Medium" : "Easy",
        estimatedTime: "5 mins"
      },
      {
        category: "General Knowledge",
        reason: "Boost your daily streak with an interactive general intelligence quiz.",
        suggestedDifficulty: "Medium",
        estimatedTime: "4 mins"
      }
    ]
  });
});

/**
 * POST Endpoint: Submit Quiz Results
 */
app.post("/api/quiz/submit-result", (req, res) => {
  const { title, category, difficulty, score, totalQuestions, studyTimeSeconds } = req.body;

  if (!title || score === undefined || !totalQuestions) {
    return res.status(400).json({ success: false, error: "Missing required fields" });
  }

  // Calculate parameters
  const accuracy = Math.round((score / totalQuestions) * 100);
  const xpGained = score * 10 + (accuracy === 100 ? 50 : 0); // +10 XP per correct question + 50 XP bonus for perfect score

  // Record history
  const id = "h-" + Math.random().toString(36).substring(3, 9);
  userProfile.history.unshift({
    id,
    quizTitle: title,
    category: category || "General Knowledge",
    difficulty: difficulty || "Medium",
    score,
    totalQuestions,
    accuracy,
    xpEarned: xpGained,
    completedAt: new Date().toISOString(),
  });

  // Accumulate XP and stats
  const totalXP = userProfile.xp + xpGained;
  userProfile.xp = totalXP;
  userProfile.quizzesTaken += 1;
  userProfile.totalQuestionsSolved += totalQuestions;
  userProfile.studyTimeSeconds += (studyTimeSeconds || 120);

  // Compute average accuracy
  const totalAcc = userProfile.history.reduce((sum, item) => sum + item.accuracy, 0);
  userProfile.averageAccuracy = Math.round(totalAcc / userProfile.history.length);

  // Update levels
  // Levels: Beginner (<=100), Learner (101-300), Explorer (301-600), Scholar (601-1000), Master (1001-2000), Grand Master (2001+)
  let nextLevel = "Beginner";
  if (totalXP > 2000) nextLevel = "Grand Master";
  else if (totalXP > 1000) nextLevel = "Master";
  else if (totalXP > 600) nextLevel = "Scholar";
  else if (totalXP > 300) nextLevel = "Explorer";
  else if (totalXP > 100) nextLevel = "Learner";
  
  userProfile.level = nextLevel;

  // Unlock Achievements evaluation
  userProfile.achievements = userProfile.achievements.map((ach) => {
    if (ach.unlocked) return ach;

    let unlock = false;
    if (ach.id === "first-quiz" && userProfile.quizzesTaken >= 1) {
      unlock = true;
    } else if (ach.id === "century-mark" && userProfile.totalQuestionsSolved >= 100) {
      unlock = true;
    } else if (ach.id === "undefeated" && accuracy === 100) {
      unlock = true;
    } else if (ach.id === "dedicated" && userProfile.streak >= 3) {
      unlock = true;
    } else if (ach.id === "category-master") {
      const distinctCats = new Set(userProfile.history.map((h) => h.category.toLowerCase()));
      if (distinctCats.size >= 3) unlock = true;
    }

    if (unlock) {
      return {
        ...ach,
        unlocked: true,
        unlockedAt: new Date().toISOString(),
      };
    }
    return ach;
  });

  res.json({
    success: true,
    xpEarned: xpGained,
    accuracy,
    newXP: totalXP,
    newLevel: nextLevel,
    profile: userProfile,
  });
});

/**
 * POST Endpoint: Generate AI Quiz from raw topics, text, or file notes
 */
app.post("/api/quiz/generate", async (req, res) => {
  const { topic, mode, difficulty, numQuestions, type } = req.body;

  const targetTopic = (topic || "General Intellectual Analytics").trim();
  const targetDiff = difficulty || "Medium";
  const targetCount = Number(numQuestions) || 5;
  const targetType = type || "MCQ";

  console.log(`Requested creation of quiz: topic="${targetTopic}", difficulty="${targetDiff}", count=${targetCount}, type="${targetType}"`);

  // Check check-mode: If user chose technology or programming offline and fallback, load instantly
  const lcTopic = targetTopic.toLowerCase();
  
  // Try calling real Google Gemini API
  const genAI = getGenAI();
  if (genAI) {
    try {
      const prompt = `Generate a standard academic quiz with exactly ${targetCount} questions on the topic: "${targetTopic}".
Type of questions desired: "${targetType}".
Overall intended academic difficulty level of the quiz: "${targetDiff}".

Strict Requirements:
1. Return output strictly conforming to JSON format with the correct response schema.
2. For each question, ensure that the correctAnswer fits perfectly and is exactly one of the values inside the "options" list (or match true/false exact letters if True/False).
3. Under "explanation", provide a solid explanation of why the correct option is indeed correct. Keep it highly educational and generated by Gemini.
4. "difficultySuggestion" should correspond to either "Easy", "Medium", or "Hard" for individual questions.
5. If the type is "Fill in the Blank", the "options" array should be empty, and the "correctAnswer" should containing the exact word or short phrase that fills the blank correctly.

Provide the response in raw JSON format to be parsed instantly.`;

      const response = await genAI.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          systemInstruction: "You are an elite, professional school teacher and academic testing syllabus designer. You design elegant, highly accurate multiple-choice and fill-in-the-blank questions based on text or topics. Your responses are ALWAYS parseable, pristine JSON conforming to the structural schema requested.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: {
                type: Type.STRING,
                description: "The name or heading of the quiz",
              },
              category: {
                type: Type.STRING,
                description: "The primary high-level subject category which best fits from: [Technology, Programming, UPSC, Science, Mathematics, History, Geography, Current Affairs, English, Aptitude, Business, Finance, AI & Machine Learning, Medical, General Knowledge]"
              },
              difficulty: {
                type: Type.STRING,
                description: "Calculated aggregate difficulty level"
              },
              questions: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.INTEGER },
                    questionText: { type: Type.STRING, description: "The clear question question text. Use blanks like '________' for fill in the blanks" },
                    type: { type: Type.STRING, description: "Must be exactly: MCQ, True/False, or Fill in the Blank" },
                    options: {
                      type: Type.ARRAY,
                      items: { type: Type.STRING },
                      description: "List of choices (MCQ option strings), empty if type is 'Fill in the Blank'"
                    },
                    correctAnswer: { type: Type.STRING, description: "The precise option string (must match exactly) or short phrase answering the blank" },
                    explanation: { type: Type.STRING, description: "Detailed summary of structural reasons why this is the perfect answer" },
                    difficultySuggestion: { type: Type.STRING, description: "One of: Easy, Medium, Hard" }
                  },
                  required: ["id", "questionText", "type", "options", "correctAnswer", "explanation", "difficultySuggestion"]
                }
              }
            },
            required: ["title", "category", "difficulty", "questions"]
          }
        },
      });

      const responseText = response.text;
      if (!responseText) {
        throw new Error("No response string fetched from Gemini model.");
      }

      const cleanJson = JSON.parse(responseText.trim());
      return res.json({
        success: true,
        source: "Gemini AI",
        quiz: cleanJson
      });
    } catch (apiError: any) {
      console.error("Gemini API generation error, executing instant educational offline fallback:", apiError);
      // Fallback below
    }
  }

  // Offline Fallback Selector for high reliability
  let fallbackQuiz = null;
  for (const [key, quizzes] of Object.entries(PRESEEDED_QUIZZES)) {
    if (lcTopic.includes(key)) {
      fallbackQuiz = quizzes[0];
      break;
    }
  }

  if (!fallbackQuiz) {
    // Generate a beautiful, custom dynamic fallback quiz aligned with the exact topic!
    fallbackQuiz = {
      title: `General Intelligence: ${targetTopic.charAt(0).toUpperCase() + targetTopic.slice(1)}`,
      category: "General Knowledge",
      difficulty: targetDiff,
      questions: [
        {
          id: 1,
          questionText: `Which of the following is core to the understanding of "${targetTopic}"?`,
          type: "MCQ",
          options: ["Theoretical foundational structures", "Uncorrelated random noise", "Deprecated historical legacy code", "All of the above"],
          correctAnswer: "Theoretical foundational structures",
          explanation: `Foundational frameworks represent the highest structure when building systems related to ${targetTopic}.`,
          difficultySuggestion: "Easy"
        },
        {
          id: 2,
          questionText: `The application of modern methodology is critical to exploring "${targetTopic}".`,
          type: "True/False",
          options: ["True", "False"],
          correctAnswer: "True",
          explanation: "Consistent modern development guidelines always yield optimal results in educational and scientific exploration.",
          difficultySuggestion: "Easy"
        },
        {
          id: 3,
          questionText: `In the study of ${targetTopic}, researchers use standardized ________ and tests to gather objective data.`,
          type: "Fill in the Blank",
          options: [],
          correctAnswer: "metrics",
          explanation: "Objective analysis requires standardized metric comparisons to eliminate individual cognitive bias.",
          difficultySuggestion: "Medium"
        },
        {
          id: 4,
          questionText: `Which factor acts as the largest catalyst for progression in "${targetTopic}"?`,
          type: "MCQ",
          options: ["Technological compute bottlenecks", "Collaborative community review", "Political geographical disputes", "Excessive marketing promotion"],
          correctAnswer: "Collaborative community review",
          explanation: "Open and shared peer-review contributes faster iteration speed and overall accuracy verification.",
          difficultySuggestion: "Medium"
        }
      ]
    };
  }

  // Adjust count if requested different
  if (fallbackQuiz && fallbackQuiz.questions.length > targetCount) {
    fallbackQuiz = {
      ...fallbackQuiz,
      questions: fallbackQuiz.questions.slice(0, targetCount)
    };
  }

  res.json({
    success: true,
    source: "Minimastic Core (Offline Engine)",
    quiz: fallbackQuiz
  });
});

// Configure Vite or Static server
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[MINIMASTIC BACKEND READY] Serving full-stack on port ${PORT}`);
  });
}

startServer();
